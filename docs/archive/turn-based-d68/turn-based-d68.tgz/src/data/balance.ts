// 모든 밸런스 수치는 여기서 조정한다 (기획서 15장: 코드 수정 없이 조정).
// [결정] = 결정 로그 확정값, [가설] = 시뮬레이션으로 조정할 값.

export const BALANCE = {
  battle: {
    tick: 0.1, // 초
    maxTime: 90, // [가설] 전투 제한 시간
    gaugeMax: 100, // 행동 게이지: 매 틱 spd*tick 만큼 차고 100에서 행동
    energyOnBasic: 12,
    energyOnActive: 20,
    energyOnHit: 4,
    variance: 0.05, // ±5%
    defK: 60, // 피해 = 공격 × 계수 × defK/(defK+방어)
  },
  element: {
    // [결정 D14] 물>불>숲>대지>전기>물
    cycle: ['water', 'fire', 'forest', 'earth', 'electric'] as const,
    advantage: 2, // D68: 턴제 전투 — 상성 ×2
    disadvantage: 0.5, // D68: 효과가 별로 ×0.5
    synergyAtk: 0.08, // [가설] 상생 인접 아군 공격 +8%
  },
  rows: {
    // [결정 D12]
    frontDamageTaken: 0.9,
    midSupportBonus: 0.1,
    backRangedBonus: 0.1,
    roleMatchBonus: 0.1,
  },
  growth: {
    maxLevel: 50, // D68: 경험치 레벨업
    // 골드로 레벨업 (D32): L→L+1 비용 = levelCostBase × levelCostGrowth^(L-1)
    levelCostBase: 20,
    levelCostGrowth: 1.3,
    joinLevelRatio: 0.8, // 새 동료는 최고 레벨의 80%로 합류
    battleXp: false, // 전투 경험치 (D32에서 끔)
    statPerLevel: 0.09, // [가설] 레벨당 +9%
    statPerRank: 0.12, // [가설] 승급당 +12%
    maxRank: 5,
    // 승급 비용 [가설]: rank -> 다음 rank
    rankCost: [
      { stones: 5, gold: 150, minLevel: 4 },
      { stones: 12, gold: 400, minLevel: 8 },
      { stones: 25, gold: 900, minLevel: 12 },
      { stones: 45, gold: 1800, minLevel: 18 },
      { stones: 70, gold: 3200, minLevel: 24 },
    ],
    // E+F [결정 D25]
    catchUpRatio: 0.8,
    catchUpMultiplier: 3,
    catchUpMinGap: 3, // [가설]
    mentorLevel: 20,
    mentorBonus: 0.3,
    bonusCap: 3.5,
  },
  enemy: {
    statPerLevel: 0.1,
    xpPerLevel: 0.12, // [가설] 적 레벨당 경험치 +12%
    goldPerLevel: 0.1,
    stoneChanceMul: 0.6,
  },
  condition: {
    // P0 단순화(D32): 컨디션·경상 효과를 끔. 켜려면 true.
    enabled: false,
    // [결정 D20] 개인 단위
    lossNormal: -5,
    lossBoss: -8,
    lowHp: -3, // 패배 시에만
    ko: -10,
    perBattleCap: -15,
    tiers: [
      { min: 80, label: '최상', mul: 1.0 },
      { min: 60, label: '양호', mul: 0.97 },
      { min: 40, label: '피로', mul: 0.93 },
      { min: 20, label: '지침', mul: 0.87 },
      { min: 0, label: '탈진', mul: 0.8 },
    ],
    naturalPerHour: 5, // [가설]
    restPerHour: 15, // [가설]
    injuryChanceOnKo: 0.25, // [가설]
    injuryAtkPenalty: 0.05,
    injuryNaturalHours: 6, // [결정 D26]
    injuryRestHours: 2, // [결정 D26]
    clinicGold: 120, // [가설]
  },
  activity: {
    trainingHours: 1,
    gatheringHours: 2,
    slots: { training: 2, gathering: 2, rest: 3 }, // [결정 D22]
    // 1시간 훈련 XP = 기준 XP × 레벨 계수 [가설]
    trainingXpBase: 60,
    trainingXpPerLevel: 30,
    // 2시간 채집 보상 [가설]
    gatheringReward: { stones: 10, gold: 300 },
  },
  idle: {
    // [결정 D21] 최대 12시간. 시간당 골드 = goldPerHour + goldPerClearedTile × 클리어한 칸 수
    capHours: 12,
    goldPerHour: 40,
    goldPerClearedTile: 12,
    stonesPerHour: 0.5,
  },
  power: {
    easyAt: 1.2,
    fairAt: 1.0,
  },
  summon: {
    cost: 10, // 🔮 속성 소환 1회 비용 (그 속성 스피릿 중 하나)
    randomCost: 6, // 🔮 전체 랜덤 소환 1회 비용 (모든 스피릿 중 하나)
  },
  evolution: {
    // [결정 D60] 등급(레어·유니크)은 없다. 같은 스피릿이 다시 소환돼야 진화한다.
    levelCap: [10, 25, 30], // 진화 단계별 최대 레벨
    copies: [1, 2], // 1→2단계, 2→3단계에 필요한 중복 소환 수
    statMul: [1, 1.15, 1.32], // 진화 단계별 능력치 배율
  },
  duel: {
    // [D68] 턴제 전투 수치
    starterLevel: 5, // 시작 동료 레벨
    hpMul: 1, // 전투 체력 배율
    bossHpMul: 0.32, // 보스 체력 배율 (원래 분대 전투용 체력이라 1:1에선 줄임)
    dmgMul: 1.2, // 피해 계수: 위력/40 × 공격 × dmgMul × 방어감쇠
    stab: 1.5, // 같은 속성 기술
    xpMul: 1.6, // 경험치 배율
    tutorialXpMul: 1.6, // P00 튜토리얼 경험치 배율
    benchXp: 0.5, // 전투에 안 나간 파티 동료가 받는 경험치 비율
    captureRate: 0.75, // 포획 기본 확률 (체력이 낮을수록·상태이상이면 ↑)
    potionRatio: 0.5, // 회복약: 최대 체력의 50%
    maxEnemies: 3, // 한 전투의 적 수 상한 (보스 포함)
    maxTurns: 80,
    potionCost: 40, // 상점 가격 (골드)
    orbCost: 120,
  },
  respawn: {
    // [결정 D59] 이긴 칸은 비었다가 시간이 지나면 몬스터가 다시 나타난다 (분)
    battleMin: 10,
    tutorialBattleMin: 1, // P00 일반 칸 (골드 벌기 연습용, D63)
    eliteMin: 60,
    bossMin: 6 * 60, // 중간 보스
    regionBossMin: 24 * 60,
  },
  deploy: {
    initialMax: 3, // [결정 D11]
  },
  time: {
    rollbackToleranceMs: 5 * 60_000,
  },
} as const;

export type Balance = typeof BALANCE;
