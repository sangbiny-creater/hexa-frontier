// 기술 표 (D68: 턴제 커맨드 전투). 기술은 레벨이 오르면 배우고, 한 번에 4개까지 쓴다.
// element: null = 무속성(상성·같은 속성 보너스 없음). cat: 물리는 방어, 마법은 마법방어로 막힌다. status = 변화 기술.
import type { Element } from '../core/types';

export type MoveCat = 'phys' | 'magic' | 'status';
export type Stat = 'atk' | 'def' | 'spd';
export type Status = 'burn' | 'poison' | 'para';

export type MoveEffect =
  | { kind: 'status'; status: Status; chance: number }
  | { kind: 'buff'; stat: Stat; stages: number }
  | { kind: 'debuff'; stat: Stat; stages: number; chance: number }
  | { kind: 'heal'; ratio: number }
  | { kind: 'drain'; ratio: number };

export interface MoveDef {
  id: string;
  name: string;
  element: Element | null;
  cat: MoveCat;
  power: number;
  pp: number;
  acc: number; // 0~100
  priority?: number;
  effect?: MoveEffect;
  desc: string;
}

const m = (d: MoveDef) => d;

export const MOVES: Record<string, MoveDef> = {
  // 무속성
  tackle: m({ id: 'tackle', name: '들이받기', element: null, cat: 'phys', power: 40, pp: 35, acc: 100, desc: '온몸으로 부딪친다.' }),
  quick: m({ id: 'quick', name: '날쌘 발걸음', element: null, cat: 'phys', power: 35, pp: 20, acc: 100, priority: 1, desc: '반드시 먼저 공격한다.' }),
  growl: m({ id: 'growl', name: '위협', element: null, cat: 'status', power: 0, pp: 30, acc: 100, effect: { kind: 'debuff', stat: 'atk', stages: 1, chance: 100 }, desc: '상대의 공격을 1단계 낮춘다.' }),
  harden: m({ id: 'harden', name: '굳히기', element: null, cat: 'status', power: 0, pp: 30, acc: 100, effect: { kind: 'buff', stat: 'def', stages: 1 }, desc: '자신의 방어를 1단계 올린다.' }),
  focus: m({ id: 'focus', name: '힘 모으기', element: null, cat: 'status', power: 0, pp: 10, acc: 100, effect: { kind: 'buff', stat: 'atk', stages: 2 }, desc: '자신의 공격을 2단계 올린다.' }),
  // 💧 물
  bubble: m({ id: 'bubble', name: '물방울 탄', element: 'water', cat: 'magic', power: 40, pp: 30, acc: 100, effect: { kind: 'debuff', stat: 'spd', stages: 1, chance: 10 }, desc: '물방울을 쏜다. 가끔 상대의 속도를 낮춘다.' }),
  aqua_jet: m({ id: 'aqua_jet', name: '물살 돌격', element: 'water', cat: 'phys', power: 40, pp: 20, acc: 100, priority: 1, desc: '물을 두르고 먼저 돌진한다.' }),
  water_pulse: m({ id: 'water_pulse', name: '물결 울림', element: 'water', cat: 'magic', power: 65, pp: 15, acc: 100, desc: '물결의 파동을 날린다.' }),
  tidal: m({ id: 'tidal', name: '큰 물결', element: 'water', cat: 'magic', power: 95, pp: 5, acc: 90, desc: '거대한 파도로 덮친다.' }),
  shell_guard: m({ id: 'shell_guard', name: '조개 방패', element: 'water', cat: 'status', power: 0, pp: 10, acc: 100, effect: { kind: 'buff', stat: 'def', stages: 2 }, desc: '자신의 방어를 2단계 올린다.' }),
  // 🔥 불
  ember: m({ id: 'ember', name: '불씨 탄', element: 'fire', cat: 'magic', power: 40, pp: 25, acc: 100, effect: { kind: 'status', status: 'burn', chance: 10 }, desc: '작은 불꽃. 가끔 화상을 입힌다.' }),
  flame_claw: m({ id: 'flame_claw', name: '불꽃 할퀴기', element: 'fire', cat: 'phys', power: 65, pp: 15, acc: 100, effect: { kind: 'status', status: 'burn', chance: 10 }, desc: '불타는 발톱으로 할퀸다.' }),
  fireball: m({ id: 'fireball', name: '불덩이', element: 'fire', cat: 'magic', power: 75, pp: 10, acc: 95, effect: { kind: 'status', status: 'burn', chance: 20 }, desc: '불덩이를 던진다. 화상 20%.' }),
  inferno: m({ id: 'inferno', name: '홍염', element: 'fire', cat: 'magic', power: 100, pp: 5, acc: 85, effect: { kind: 'status', status: 'burn', chance: 30 }, desc: '모든 것을 태우는 불꽃. 빗나갈 수 있다.' }),
  // 🌿 숲
  leaf_cut: m({ id: 'leaf_cut', name: '잎새 베기', element: 'forest', cat: 'phys', power: 50, pp: 25, acc: 100, desc: '날카로운 잎으로 벤다.' }),
  absorb: m({ id: 'absorb', name: '생기 빨기', element: 'forest', cat: 'magic', power: 40, pp: 25, acc: 100, effect: { kind: 'drain', ratio: 0.5 }, desc: '준 피해의 절반만큼 회복한다.' }),
  poison_spore: m({ id: 'poison_spore', name: '독 포자', element: 'forest', cat: 'status', power: 0, pp: 20, acc: 85, effect: { kind: 'status', status: 'poison', chance: 100 }, desc: '상대를 중독시킨다(매 턴 피해).' }),
  heal_bloom: m({ id: 'heal_bloom', name: '새싹 숨결', element: 'forest', cat: 'status', power: 0, pp: 5, acc: 100, effect: { kind: 'heal', ratio: 0.5 }, desc: '최대 체력의 절반을 회복한다.' }),
  solar: m({ id: 'solar', name: '고목 내려치기', element: 'forest', cat: 'magic', power: 90, pp: 5, acc: 100, desc: '숲의 힘을 모아 내리친다.' }),
  // ⛰️ 대지
  rock_throw: m({ id: 'rock_throw', name: '자갈 날리기', element: 'earth', cat: 'phys', power: 50, pp: 15, acc: 90, desc: '돌을 던진다.' }),
  mud: m({ id: 'mud', name: '흙탕 세례', element: 'earth', cat: 'magic', power: 40, pp: 15, acc: 100, effect: { kind: 'debuff', stat: 'spd', stages: 1, chance: 100 }, desc: '진흙을 뿌려 상대의 속도를 낮춘다.' }),
  charge: m({ id: 'charge', name: '바위 굴리기', element: 'earth', cat: 'phys', power: 80, pp: 10, acc: 95, desc: '온몸으로 돌진한다.' }),
  quake: m({ id: 'quake', name: '땅 가르기', element: 'earth', cat: 'phys', power: 100, pp: 5, acc: 100, desc: '땅을 뒤흔든다.' }),
  // 🌪️ 바람
  gust: m({ id: 'gust', name: '회오리 날', element: 'electric', cat: 'magic', power: 40, pp: 35, acc: 100, desc: '세찬 바람을 일으킨다.' }),
  feather: m({ id: 'feather', name: '깃털 화살', element: 'electric', cat: 'phys', power: 55, pp: 20, acc: 100, desc: '날카로운 깃털을 날린다.' }),
  spark: m({ id: 'spark', name: '찌릿 박치기', element: 'electric', cat: 'phys', power: 45, pp: 20, acc: 100, effect: { kind: 'status', status: 'para', chance: 30 }, desc: '전기를 두르고 부딪친다. 마비 30%.' }),
  tailwind: m({ id: 'tailwind', name: '뒷바람', element: 'electric', cat: 'status', power: 0, pp: 15, acc: 100, effect: { kind: 'buff', stat: 'spd', stages: 2 }, desc: '자신의 속도를 2단계 올린다.' }),
  storm: m({ id: 'storm', name: '뇌운', element: 'electric', cat: 'magic', power: 95, pp: 5, acc: 85, effect: { kind: 'status', status: 'para', chance: 20 }, desc: '번개 섞인 폭풍. 빗나갈 수 있다.' }),
};

/** 종족별로 배우는 기술: [레벨, 기술] */
export const LEARNSETS: Record<string, [number, string][]> = {
  tideshell: [[1, 'tackle'], [1, 'harden'], [4, 'aqua_jet'], [8, 'shell_guard'], [11, 'water_pulse'], [17, 'charge'], [24, 'tidal']],
  igni: [[1, 'ember'], [1, 'growl'], [4, 'quick'], [8, 'flame_claw'], [12, 'fireball'], [18, 'tailwind'], [24, 'inferno']],
  sylphy: [[1, 'absorb'], [1, 'growl'], [4, 'heal_bloom'], [8, 'poison_spore'], [12, 'leaf_cut'], [18, 'bubble'], [24, 'solar']],
  galewing: [[1, 'gust'], [1, 'quick'], [4, 'feather'], [8, 'tailwind'], [12, 'spark'], [18, 'ember'], [24, 'storm']],
  rocky: [[1, 'tackle'], [1, 'rock_throw'], [5, 'harden'], [9, 'mud'], [13, 'charge'], [19, 'focus'], [25, 'quake']],
  leafpup: [[1, 'tackle'], [1, 'growl'], [3, 'leaf_cut'], [7, 'quick'], [11, 'focus'], [16, 'absorb'], [22, 'solar']],
  tidekit: [[1, 'bubble'], [1, 'growl'], [4, 'quick'], [8, 'water_pulse'], [13, 'mud'], [19, 'tidal']],
  skywarden: [[1, 'tackle'], [1, 'gust'], [4, 'spark'], [8, 'feather'], [13, 'focus'], [19, 'storm']],
  leafkit: [[1, 'absorb'], [1, 'harden'], [4, 'poison_spore'], [8, 'heal_bloom'], [12, 'mud'], [18, 'solar']],
  // 보스 (포획 불가)
  elder_treant: [[1, 'leaf_cut'], [1, 'absorb'], [1, 'harden'], [12, 'solar']],
  stone_giant: [[1, 'rock_throw'], [1, 'charge'], [1, 'harden'], [1, 'quake']],
  tide_lord: [[1, 'bubble'], [1, 'water_pulse'], [1, 'growl'], [1, 'tidal']],
  storm_king: [[1, 'spark'], [1, 'feather'], [1, 'tailwind'], [1, 'storm']],
  boar_chief: [[1, 'rock_throw'], [1, 'growl'], [1, 'harden'], [1, 'charge']],
};

/** 그 레벨까지 배운 기술 전부 (배운 순서) */
export function learnedMoves(species: string, level: number): string[] {
  return (LEARNSETS[species] ?? [[1, 'tackle']]).filter(([lv]) => lv <= level).map(([, id]) => id);
}

/** 기본으로 쓰는 4개: 가장 최근에 배운 4개 */
export function defaultMoves(species: string, level: number): string[] {
  return learnedMoves(species, level).slice(-4);
}

/** 이 레벨에서 새로 배우는 기술 */
export function movesAt(species: string, level: number): string[] {
  return (LEARNSETS[species] ?? []).filter(([lv]) => lv === level).map(([, id]) => id);
}
