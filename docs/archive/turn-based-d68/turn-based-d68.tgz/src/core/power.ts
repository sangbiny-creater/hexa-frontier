// 상성 요약 (UI 안내용). 실제 승패는 턴제 전투(duel.ts)가 결정한다.
import { ENCOUNTERS, ENEMIES } from '../data/enemies';
import { SPIRITS } from '../data/spirits';
import { elementMultiplier } from './board';
import { duelEnemies } from './duel';

export type Matchup = 'adv' | 'dis' | 'even';

/** 스피릿(자기 속성 기술 기준)이 이 전투의 적들을 공격할 때 평균 상성 (보스 가중치 3) */
export function attackMatchup(spiritId: string, encounterId: string): Matchup {
  let sum = 0;
  let w = 0;
  for (const e of duelEnemies(encounterId)) {
    const def = ENEMIES[e.enemyId];
    const k = def.isBoss ? 3 : 1;
    sum += elementMultiplier(SPIRITS[spiritId].element, def.element) * k;
    w += k;
  }
  const m = sum / w;
  return m > 1.05 ? 'adv' : m < 0.95 ? 'dis' : 'even';
}

/** 이 전투에 쓰면 좋은 순서 (레벨 + 상성: 유리 +4레벨, 불리 -4레벨로 친다) */
export function suggestTeam(owned: string[], encounterId: string, max: number, level: (id: string) => number = () => 0): string[] {
  const score = (id: string) => ({ adv: 4, even: 0, dis: -4 })[attackMatchup(id, encounterId)] + level(id);
  return [...owned].sort((a, b) => score(b) - score(a)).slice(0, max);
}

export { ENCOUNTERS };
