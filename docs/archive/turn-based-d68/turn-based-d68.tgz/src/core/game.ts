// 게임 상태와 행동 (D68: 턴제 커맨드 전투 + 포획 + 경험치 성장).
// 모든 함수는 state를 직접 변경한다 (UI는 복사본을 넘긴다). 시간은 항상 인자로 받는다.
import { BALANCE } from '../data/balance';
import { ENCOUNTERS, ENEMIES } from '../data/enemies';
import { MAPS, TILE_BY_ID, TILES, TUTORIAL_END, stageCode, type TileDef } from '../data/map';
import { defaultMoves, learnedMoves, movesAt } from '../data/moves';
import { DEFAULT_SLOT, SPIRITS } from '../data/spirits';
import { HOUR } from './clock';
import { createDuel, duelEnemies, type Duel } from './duel';
import { grantXp, rankUpCost, xpToNext } from './growth';
import { axialNeighbors } from './hex';
import { createRng, hashSeed } from './rng';
import { fixJosa } from './text';
import type { Element, OwnedSpirit } from './types';

export const SAVE_VERSION = 9;

export interface TutorialState {
  introSeen: boolean;
  done: boolean;
  /** 한 번 본 설명 팝업 id */
  seen: string[];
}

export function newTutorial(): TutorialState {
  return { introSeen: false, done: false, seen: [] };
}

export interface GameState {
  version: number;
  createdAt: number;
  lastTickAt: number;
  lastIdleClaimAt: number;
  gold: number;
  stones: number;
  summonStones: number; // 🔮 결정: 포획 1개, 소환 10개
  items: { potion: number };
  spirits: Record<string, OwnedSpirit>;
  formation: Record<string, number>; // 파티: spiritId → 순서 (작을수록 앞, 0이 선두)
  maxDeploy: number;
  cleared: string[];
  nodes: string[];
  battleCounter: number;
  lastTile: string;
  bossAttempts: Record<string, number>;
  attempts: Record<string, number>;
  captures: number;
  messages: string[];
  tutorial: TutorialState;
  map: string;
  respawnAt: Record<string, number>;
  summonCounter: number;
  settings: { skipBattle: boolean };
}

/** 시작 동료: 🔥엠버 칙 */
export const STARTER = 'igni';

export function newGame(now: number): GameState {
  const s: GameState = {
    version: SAVE_VERSION,
    createdAt: now,
    lastTickAt: now,
    lastIdleClaimAt: now,
    gold: 100,
    stones: 0,
    summonStones: 0,
    items: { potion: 2 },
    spirits: {},
    formation: {},
    maxDeploy: BALANCE.deploy.initialMax,
    cleared: ['start'],
    nodes: [],
    battleCounter: 0,
    lastTile: 'start',
    bossAttempts: {},
    attempts: {},
    captures: 0,
    messages: [],
    tutorial: newTutorial(),
    map: 'P00',
    respawnAt: {},
    summonCounter: 0,
    settings: { skipBattle: false },
  };
  addSpirit(s, STARTER, BALANCE.duel.starterLevel);
  return s;
}

export function stageForLevel(level: number): 1 | 2 | 3 {
  const at = BALANCE.evolution.levelCap;
  return level >= at[1] ? 3 : level >= at[0] ? 2 : 1;
}

export function addSpirit(s: GameState, id: string, level: number) {
  if (s.spirits[id]) return;
  s.spirits[id] = { defId: id, level, xp: 0, rank: 0, stage: stageForLevel(level), copies: 0, condition: 100, injured: false, injuryProgress: 0 };
  if (Object.keys(s.formation).length < s.maxDeploy) s.formation[id] = nextOrder(s);
}

function nextOrder(s: GameState) {
  return Math.max(-1, ...Object.values(s.formation)) + 1;
}

function msg(s: GameState, text: string) {
  s.messages.unshift(fixJosa(text));
  s.messages = s.messages.slice(0, 30);
}

// ───────── 파티 ─────────

/** 전투에 나가는 순서대로 */
export function partyIds(s: GameState): string[] {
  return Object.keys(s.formation)
    .filter((id) => s.spirits[id])
    .sort((a, b) => s.formation[a] - s.formation[b]);
}

/** 파티에 넣기/빼기 */
export function toggleParty(s: GameState, id: string): string | null {
  if (!s.spirits[id]) return '보유하지 않은 스피릿';
  if (s.formation[id] !== undefined) {
    if (Object.keys(s.formation).length <= 1) return '최소 1명은 파티에 있어야 해요';
    delete s.formation[id];
    normalize(s);
    return null;
  }
  if (Object.keys(s.formation).length >= s.maxDeploy) return `파티는 ${s.maxDeploy}명까지예요. 먼저 한 명을 빼세요.`;
  s.formation[id] = nextOrder(s);
  return null;
}

/** 선두로 (전투에 가장 먼저 나감) */
export function makeLead(s: GameState, id: string): string | null {
  if (s.formation[id] === undefined) {
    if (Object.keys(s.formation).length >= s.maxDeploy) {
      // 꽉 찼으면 맨 뒤 동료와 교체
      const last = partyIds(s).at(-1)!;
      delete s.formation[last];
    }
    s.formation[id] = -1;
  } else s.formation[id] = -1;
  normalize(s);
  return null;
}

/** 파티를 이 순서로 맞춘다 */
export function setParty(s: GameState, ids: string[]) {
  s.formation = {};
  ids.slice(0, s.maxDeploy).forEach((id, i) => s.spirits[id] && (s.formation[id] = i));
}

function normalize(s: GameState) {
  partyIds(s).forEach((id, i) => (s.formation[id] = i));
}

/** 하위 호환: 예전 편성 API (slot이 null이면 빼기) */
export function setFormation(s: GameState, id: string, slot: number | null): string | null {
  if (slot === null) return s.formation[id] === undefined ? null : toggleParty(s, id);
  if (s.formation[id] === undefined) return toggleParty(s, id);
  return null;
}

export function spiritMoves(s: GameState, id: string): string[] {
  const sp = s.spirits[id];
  return sp.moves?.length ? sp.moves : defaultMoves(id, sp.level);
}

/** 쓸 기술 4개 고르기 (배운 기술 중에서) */
export function setMoves(s: GameState, id: string, moves: string[]): string | null {
  const sp = s.spirits[id];
  const learned = learnedMoves(id, sp.level);
  if (!moves.length || moves.length > 4 || moves.some((m) => !learned.includes(m))) return '배운 기술 중 1~4개를 고르세요';
  sp.moves = moves;
  return null;
}

// ───────── 맵 ─────────

const COORD_INDEX = new Map(TILES.map((t) => [`${t.map}:${t.q},${t.r}`, t]));

export function neighborsOf(tile: TileDef): TileDef[] {
  return axialNeighbors(tile.q, tile.r)
    .map(([q, r]) => COORD_INDEX.get(`${tile.map}:${q},${r}`))
    .filter((t): t is TileDef => !!t);
}

export function reachableTiles(s: GameState): Set<string> {
  const out = new Set<string>();
  for (const id of s.cleared) {
    const t = TILE_BY_ID[id];
    if (!t || t.map !== s.map) continue;
    for (const n of neighborsOf(t)) if (!s.cleared.includes(n.id)) out.add(n.id);
  }
  return out;
}

/** 지도에서 주인공이 걸어갈 길: 지금 칸 → 목표 칸 (클리어한 칸만 밟는다) */
export function walkPath(s: GameState, to: string): string[] {
  const from = TILE_BY_ID[s.lastTile]?.map === s.map ? s.lastTile : MAPS[s.map].startId;
  if (from === to) return [to];
  const ok = (id: string) => s.cleared.includes(id) || id === to;
  const prev = new Map<string, string>([[from, '']]);
  const q = [from];
  while (q.length) {
    const cur = q.shift()!;
    if (cur === to) break;
    for (const n of neighborsOf(TILE_BY_ID[cur])) if (!prev.has(n.id) && ok(n.id)) (prev.set(n.id, cur), q.push(n.id));
  }
  if (!prev.has(to)) return [to];
  const path: string[] = [];
  for (let c = to; c; c = prev.get(c)!) path.unshift(c);
  return path;
}

export function mapUnlocked(s: GameState, mapId: string): boolean {
  if (mapId === 'P00') return true;
  if (mapId === 'P01') return s.cleared.includes(TUTORIAL_END) || s.tutorial.done;
  return false;
}

export function travel(s: GameState, mapId: string): string | null {
  const m = MAPS[mapId];
  if (!m) return '준비 중인 지역이에요.';
  if (!mapUnlocked(s, mapId)) return '튜토리얼(P00)을 먼저 끝내세요.';
  s.map = mapId;
  if (!s.cleared.includes(m.startId)) s.cleared.push(m.startId);
  if (TILE_BY_ID[s.lastTile]?.map !== mapId) s.lastTile = m.startId;
  return null;
}

export function respawnMs(tile: TileDef): number {
  const R = BALANCE.respawn;
  const enc = tile.encounterId ? ENCOUNTERS[tile.encounterId] : null;
  const normal = tile.map === 'P00' ? R.tutorialBattleMin : R.battleMin;
  const min = enc?.bossKind === 'region' ? R.regionBossMin : enc?.bossKind ? R.bossMin : tile.kind === 'elite' ? R.eliteMin : normal;
  return min * 60_000;
}

export function respawnLeft(s: GameState, tileId: string, now: number): number {
  return Math.max(0, (s.respawnAt[tileId] ?? 0) - now);
}

export function visibleTiles(s: GameState): Set<string> {
  const out = new Set<string>(s.cleared.filter((id) => TILE_BY_ID[id]?.map === s.map));
  for (const id of reachableTiles(s)) out.add(id);
  return out;
}

// ───────── 시간 ─────────

export function tick(s: GameState, now: number) {
  if (now > s.lastTickAt) s.lastTickAt = now;
}

export function detectRollback(s: GameState, now: number): boolean {
  return now < s.lastTickAt - BALANCE.time.rollbackToleranceMs;
}

// ───────── 난이도 (레벨 기준) ─────────

/** 이 전투의 대표 레벨 (가장 높은 적) */
export function encounterLevel(encounterId: string): number {
  return Math.max(...duelEnemies(encounterId).map((e) => e.level));
}

/** 파티의 대표 레벨 (가장 높은 동료) */
export function partyLevel(s: GameState): number {
  return Math.max(1, ...partyIds(s).map((id) => s.spirits[id].level));
}

export type Difficulty = 'easy' | 'fair' | 'hard';
export const DIFFICULTY_LABEL: Record<Difficulty, string> = { easy: '쉬움', fair: '적정', hard: '위험' };

export function difficultyOf(s: GameState, encounterId: string): Difficulty {
  const gap = partyLevel(s) - encounterLevel(encounterId);
  return gap >= 2 ? 'easy' : gap >= -1 ? 'fair' : 'hard';
}

// ───────── 칸 들어가기 ─────────

export type EnterResult =
  | { type: 'resource'; resource: NonNullable<TileDef['resource']>; bonus: { gold: number; stones: number; summon: number; potion: number } }
  | { type: 'gate' }
  | { type: 'travel'; map: string }
  | { type: 'duel'; duel: Duel }
  | { type: 'error'; message: string };

export function canEnter(s: GameState, tileId: string, now: number): string | null {
  const tile = TILE_BY_ID[tileId];
  if (!tile) return '없는 칸';
  const cleared = s.cleared.includes(tileId);
  if (!cleared && !reachableTiles(s).has(tileId)) return '아직 갈 수 없는 칸입니다.';
  if (tile.encounterId && cleared) {
    const left = respawnLeft(s, tileId, now);
    if (left > 0) return `몬스터가 다시 나타나기까지 ${Math.ceil(left / 60_000)}분 남았어요.`;
  }
  if (!tile.encounterId && cleared && tile.kind !== 'gate') return '이미 탐험한 칸입니다.';
  return null;
}

export function enterTile(s: GameState, tileId: string, now: number): EnterResult {
  tick(s, now);
  const err = canEnter(s, tileId, now);
  if (err) return { type: 'error', message: err };
  const tile = TILE_BY_ID[tileId];
  if (tile.kind === 'gate') {
    const next = tile.map === 'P00' ? 'P01' : null;
    if (!next || !MAPS[next]) return { type: 'gate' };
    const e = travel(s, next);
    if (e) return { type: 'error', message: e };
    msg(s, `${next} ${MAPS[next].name}에 들어섰다!`);
    return { type: 'travel', map: next };
  }
  if (tile.encounterId) return { type: 'duel', duel: startDuel(s, tileId) };
  s.cleared.push(tileId);
  s.lastTile = tileId;
  s.nodes.push(tileId);
  const main = tile.map !== 'P00';
  const r = tile.resource ?? 'gold';
  const bonus = { gold: 0, stones: 0, summon: 0, potion: 0 };
  if (r === 'stones') bonus.stones = tile.amount ?? (main ? 3 + Math.floor(tile.row / 20) : 10);
  else if (r === 'summon') bonus.summon = tile.amount ?? (main ? 4 : BALANCE.summon.cost);
  else if (r === 'potion') bonus.potion = tile.amount ?? 2;
  else bonus.gold = tile.amount ?? (main ? 60 + tile.row * 6 : 150);
  s.gold += bonus.gold;
  s.stones += bonus.stones;
  s.summonStones += bonus.summon;
  s.items.potion += bonus.potion;
  msg(s, `보물: ${tile.name}`);
  return { type: 'resource', resource: r, bonus };
}

export function startDuel(s: GameState, tileId: string): Duel {
  const tile = TILE_BY_ID[tileId];
  s.battleCounter++;
  const party = partyIds(s).map((id) => ({ id, ...s.spirits[id], moves: spiritMoves(s, id) }));
  return createDuel({
    tileId,
    encounterId: tile.encounterId!,
    seed: hashSeed('duel', s.createdAt, s.battleCounter, tileId),
    party,
    potions: s.items.potion,
    orbs: s.summonStones,
  });
}

export interface DuelSummary {
  won: boolean;
  result: Duel['over'];
  firstClear: boolean;
  gold: number;
  stones: number;
  summon: number;
  xp: { id: string; gained: number; from: number; to: number }[];
  learned: { id: string; moves: string[] }[];
  evolved: { id: string; stage: number }[];
  captured: { id: string; isNew: boolean; level: number }[];
  unlocked: string[];
}

/** 경험치 지급 + 레벨업에 따른 기술 습득·진화 */
export function giveXp(s: GameState, id: string, amount: number, sum: Pick<DuelSummary, 'xp' | 'learned' | 'evolved'>) {
  const sp = s.spirits[id];
  const from = sp.level;
  grantXp(sp, amount);
  sum.xp.push({ id, gained: amount, from, to: sp.level });
  const learned: string[] = [];
  for (let L = from + 1; L <= sp.level; L++) learned.push(...movesAt(id, L));
  if (learned.length) {
    sum.learned.push({ id, moves: learned });
    // 직접 고른 기술이 있으면, 빈자리에만 새 기술을 넣는다
    if (sp.moves?.length) for (const m of learned) if (sp.moves.length < 4 && !sp.moves.includes(m)) sp.moves.push(m);
  }
  const st = stageForLevel(sp.level);
  // 한 번에 여러 단계를 넘어도 단계마다 진화 연출
  while (sp.stage < st) {
    sp.stage = (sp.stage + 1) as 2 | 3;
    sum.evolved.push({ id, stage: sp.stage });
  }
}

/** 전투가 끝나면 결과를 반영한다 */
export function finishDuel(s: GameState, d: Duel, now: number): DuelSummary {
  const tile = TILE_BY_ID[d.tileId];
  const enc = ENCOUNTERS[d.encounterId];
  const won = d.over === 'win';
  const firstClear = won && !s.cleared.includes(tile.id);
  const sum: DuelSummary = { won, result: d.over, firstClear, gold: 0, stones: 0, summon: 0, xp: [], learned: [], evolved: [], captured: [], unlocked: [] };
  s.attempts[tile.id] = (s.attempts[tile.id] ?? 0) + 1;
  if (enc.bossKind) s.bossAttempts[tile.id] = (s.bossAttempts[tile.id] ?? 0) + 1;
  // 쓰러뜨리거나 잡은 적의 골드
  for (const e of d.enemies) if (e.hp <= 0) sum.gold += e.gold;
  if (!won) sum.gold = Math.round(sum.gold * 0.5);
  const rng = createRng(d.rng ^ 0x9e3779b9);
  if (won) {
    for (const e of d.enemies) if (rng() < ENEMIES[e.defId].stoneChance * BALANCE.enemy.stoneChanceMul) sum.stones += e.isBoss ? 3 : 1;
    if (firstClear) {
      sum.gold += enc.firstClear.gold;
      sum.stones += enc.firstClear.stones;
      sum.summon = enc.firstClear.summon ?? 0;
    }
  }
  s.gold += sum.gold;
  s.stones += sum.stones;
  s.summonStones += sum.summon;
  s.items.potion = Math.max(0, s.items.potion - d.used.potion);
  s.summonStones = Math.max(0, s.summonStones - d.used.orb);
  // 포획
  for (const c of d.captured) {
    s.captures++;
    if (!s.spirits[c.species]) {
      addSpirit(s, c.species, c.level);
      sum.captured.push({ id: c.species, isNew: true, level: c.level });
      msg(s, `${SPIRITS[c.species].name}을(를) 잡았다!`);
    } else {
      // 이미 있는 동료를 또 잡으면 경험치로 (1레벨 분량)
      sum.captured.push({ id: c.species, isNew: false, level: c.level });
      d.xp[c.species] = (d.xp[c.species] ?? 0) + xpToNext(s.spirits[c.species].level);
    }
  }
  // 튜토리얼(P00)은 경험치를 더 줘서 빨리 배우고 넘어가게
  const xpMul = tile.map === 'P00' ? BALANCE.duel.tutorialXpMul : 1;
  for (const [id, amount] of Object.entries(d.xp)) if (s.spirits[id]) giveXp(s, id, Math.round(amount * xpMul), sum);
  if (won) {
    s.respawnAt[tile.id] = now + respawnMs(tile);
    if (firstClear) {
      s.cleared.push(tile.id);
      if (tile.id === 'b1') sum.unlocked.push('🏕캠프 자동 사냥이 열렸어요! 자리를 비워도 골드가 쌓여요.');
      if (enc.unlockDeploy && enc.unlockDeploy > s.maxDeploy) {
        s.maxDeploy = enc.unlockDeploy;
        sum.unlocked.push(`파티 인원이 ${s.maxDeploy}명으로 늘었어요!`);
      }
      if (tile.id === TUTORIAL_END) sum.unlocked.push('튜토리얼 끝! 지도 맨 위 길로 P01에 갈 수 있어요.');
      if (enc.bossKind === 'region') sum.unlocked.push(`${MAPS[tile.map].code} ${MAPS[tile.map].name}을(를) 돌파했습니다! 다음 지역은 준비 중이에요.`);
    }
    s.lastTile = tile.id;
  }
  msg(s, `${stageCode(tile) ?? enc.name}: ${won ? '승리' : d.over === 'run' ? '도망' : '패배'}`);
  return sum;
}

/** 경험치 벌기 좋은 칸: 이긴 일반 칸 중 쿨타임이 끝났고 레벨이 가장 높은 '쉬움·적정' 칸 */
export function bestFarmTile(s: GameState, now: number): string | null {
  const farm = s.cleared
    .map((id) => TILE_BY_ID[id])
    .filter((t) => t && t.map === s.map && t.kind === 'battle' && t.encounterId && respawnLeft(s, t.id, now) === 0);
  if (!farm.length) return null;
  const ok = farm.filter((t) => difficultyOf(s, t.encounterId!) !== 'hard').sort((a, b) => encounterLevel(b.encounterId!) - encounterLevel(a.encounterId!));
  return (ok[0] ?? farm.sort((a, b) => encounterLevel(a.encounterId!) - encounterLevel(b.encounterId!))[0]).id;
}

// ───────── 성장·상점 ─────────

export function rankUp(s: GameState, id: string): string | null {
  const sp = s.spirits[id];
  const cost = sp && rankUpCost(sp);
  if (!sp || !cost) return '더 이상 승급할 수 없습니다.';
  if (sp.level < cost.minLevel) return `Lv.${cost.minLevel} 이상이 필요합니다.`;
  if (s.stones < cost.stones || s.gold < cost.gold) return '재료가 부족합니다.';
  s.stones -= cost.stones;
  s.gold -= cost.gold;
  sp.rank++;
  msg(s, `${SPIRITS[id].name} 승급! (★${sp.rank})`);
  return null;
}

export function canRankUp(s: GameState, id: string): boolean {
  const sp = s.spirits[id];
  const cost = rankUpCost(sp);
  return !!cost && sp.level >= cost.minLevel && s.stones >= cost.stones && s.gold >= cost.gold;
}

export type ShopItem = 'potion' | 'orb';

export function shopPrice(item: ShopItem): number {
  return item === 'potion' ? BALANCE.duel.potionCost : BALANCE.duel.orbCost;
}

export function buy(s: GameState, item: ShopItem, n = 1): string | null {
  const cost = shopPrice(item) * n;
  if (s.gold < cost) return `골드가 부족해요 (${cost} 필요)`;
  s.gold -= cost;
  if (item === 'potion') s.items.potion += n;
  else s.summonStones += n;
  return null;
}

// ───────── 소환 ─────────

export const SUMMON_POOL: Record<Element, string[]> = {
  water: ['tideshell', 'tidekit'],
  fire: ['igni'],
  forest: ['sylphy', 'leafpup', 'leafkit'],
  electric: ['galewing', 'skywarden'],
  earth: ['rocky'],
};

export const ALL_SUMMONABLE = Object.values(SUMMON_POOL).flat();

export type SummonMode = Element | 'any';

export function summonCost(mode: SummonMode): number {
  return mode === 'any' ? BALANCE.summon.randomCost : BALANCE.summon.cost;
}

/** 소환은 첫 🔮결정 상자(신비한 결정)를 열면 열린다 */
export function summonUnlocked(s: GameState): boolean {
  return s.cleared.includes('a8') || s.tutorial.done || s.cleared.includes(TUTORIAL_END);
}

export function summon(s: GameState, mode: SummonMode): { spiritId: string; duplicate: boolean; levelUps: number } | { error: string } {
  if (!summonUnlocked(s)) return { error: '아직 열리지 않았어요' };
  const pool = mode === 'any' ? ALL_SUMMONABLE : SUMMON_POOL[mode];
  const cost = summonCost(mode);
  if (s.summonStones < cost) return { error: `🔮결정이 ${cost}개 필요해요` };
  s.summonStones -= cost;
  s.summonCounter++;
  const rng = createRng(hashSeed('summon', s.createdAt, s.summonCounter, mode));
  const id = pool[Math.floor(rng() * pool.length)];
  const duplicate = !!s.spirits[id];
  let levelUps = 0;
  if (duplicate) {
    const before = s.spirits[id].level;
    giveXp(s, id, xpToNext(before), { xp: [], learned: [], evolved: [] });
    levelUps = s.spirits[id].level - before;
  } else {
    // 소환한 동료는 파티 최고 레벨의 80%로 합류
    addSpirit(s, id, Math.max(1, Math.floor(partyLevel(s) * BALANCE.growth.joinLevelRatio)));
  }
  msg(s, `소환: ${SPIRITS[id].name}${duplicate ? ' (같은 동료 → 경험치)' : ''}`);
  return { spiritId: id, duplicate, levelUps };
}

// ───────── 방치 보상 ─────────

export function idleGoldPerHour(s: GameState): number {
  return BALANCE.idle.goldPerHour + BALANCE.idle.goldPerClearedTile * (s.cleared.length - 1);
}

export function idlePreview(s: GameState, now: number) {
  const I = BALANCE.idle;
  const hours = Math.max(0, Math.min(I.capHours, (now - s.lastIdleClaimAt) / HOUR));
  return { hours, gold: Math.floor(hours * idleGoldPerHour(s)), stones: Math.floor(hours * I.stonesPerHour) };
}

export function claimIdle(s: GameState, now: number) {
  if (now <= s.lastIdleClaimAt) return { hours: 0, gold: 0, stones: 0 };
  const p = idlePreview(s, now);
  s.gold += p.gold;
  s.stones += p.stones;
  s.lastIdleClaimAt = now;
  return p;
}

export function idleUnlocked(s: GameState): boolean {
  return s.cleared.includes('b1') || s.tutorial.done;
}

// ───────── 목표 ─────────

export const TUTORIAL_PATH = MAPS.P00.tiles.filter((t) => t.kind !== 'start' && t.kind !== 'gate').map((t) => t.id);

export function objectiveTile(s: GameState): string | null {
  if (s.map !== 'P00') return mainObjectiveTile(s);
  return TUTORIAL_PATH.find((id) => !s.cleared.includes(id)) ?? 'gate';
}

function mainObjectiveTile(s: GameState): string | null {
  const reach = [...reachableTiles(s)].map((id) => TILE_BY_ID[id]).filter((t) => t.stage);
  reach.sort((a, b) => a.stage! - b.stage!);
  if (reach[0]) return reach[0].id;
  // 다음 스테이지가 보물 칸 너머에 있으면 가장 아래쪽 보물 칸부터
  const res = [...reachableTiles(s)].map((id) => TILE_BY_ID[id]).filter((t) => t.kind === 'resource').sort((a, b) => a.row - b.row);
  if (res[0]) return res[0].id;
  const gate = MAPS[s.map].tiles.find((t) => t.kind === 'gate');
  return gate && reachableTiles(s).has(gate.id) ? gate.id : null;
}

export function stageProgress(s: GameState, mapId: string): { cleared: number; total: number } {
  const st = MAPS[mapId].tiles.filter((t) => t.stage);
  return { cleared: st.filter((t) => s.cleared.includes(t.id)).length, total: st.length };
}

export function currentObjective(s: GameState): string {
  if (s.map === 'P00') {
    const next = TUTORIAL_PATH.find((id) => !s.cleared.includes(id));
    if (!next) return '튜토리얼 끝! 맨 위 길로 P01에 가세요';
    const t = TILE_BY_ID[next];
    if (t.kind === 'resource') return fixJosa(`${t.name}에서 보물을 챙기세요`);
    if (s.attempts[next]) return `${t.name} 재도전: 아렌의 안내를 따라 해 보세요`;
    return `${t.name}에 도전하세요`;
  }
  const p = stageProgress(s, s.map);
  const obj = objectiveTile(s);
  const code = obj ? stageCode(TILE_BY_ID[obj]) : null;
  if (p.cleared >= p.total) return `${s.map} 돌파! 다음 지역은 준비 중 (${p.cleared}/${p.total})`;
  return `${code ? `${code} 클리어하기` : '길을 찾아 위로'} · ${p.cleared}/${p.total}`;
}

export { DEFAULT_SLOT };
