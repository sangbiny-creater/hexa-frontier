// 턴제 커맨드 전투 (D68). 몬스터 수집 RPG 장르의 1:1 교대 전투.
// - 매 턴 [기술 / 교체 / 가방(회복약·봉인 결정) / 도망] 중 하나를 고른다.
// - 빠른 쪽이 먼저 행동(선공 기술은 항상 먼저). 속성 상성 ×2/×0.5, 같은 속성 기술 ×1.5, 급소 ×1.5.
// - 물리 기술은 방어, 마법 기술은 마법방어로 막힌다. 상태이상: 화상·중독·마비.
// - 상태는 직렬화 가능한 순수 데이터(난수 상태 포함) → 같은 시드·같은 선택 = 같은 결과.
import { BALANCE } from '../data/balance';
import { ENCOUNTERS, ENEMIES } from '../data/enemies';
import { defaultMoves, MOVES, type MoveDef, type Stat, type Status } from '../data/moves';
import { SPIRITS } from '../data/spirits';
import { elementMultiplier } from './board';
import { fixJosa } from './text';
import type { Element, UnitDef } from './types';

export interface Fighter {
  uid: string;
  side: 'ally' | 'enemy';
  defId: string; // 스피릿 id 또는 몬스터 id
  species: string | null; // 포획하면 이 스피릿 (아군은 자기 자신)
  name: string;
  element: Element;
  level: number;
  stage: number;
  maxHp: number;
  hp: number;
  atk: number;
  def: number;
  res: number;
  spd: number;
  moves: { id: string; pp: number }[];
  stages: Record<Stat, number>;
  status: Status | null;
  isBoss: boolean;
  xpYield: number;
  gold: number;
  captured?: boolean;
}

export type DuelEvent =
  | { t: 'msg'; text: string }
  | { t: 'move'; uid: string; move: string }
  | { t: 'dmg'; uid: string; amount: number; hp: number; eff: 'super' | 'weak' | null; crit: boolean; resisted: boolean }
  | { t: 'heal'; uid: string; amount: number; hp: number }
  | { t: 'status'; uid: string; status: Status }
  | { t: 'stat'; uid: string; stat: Stat; stages: number }
  | { t: 'faint'; uid: string }
  | { t: 'send'; uid: string }
  | { t: 'capture'; uid: string; shakes: number; ok: boolean }
  | { t: 'xp'; spiritId: string; amount: number };

export type Command = { kind: 'move'; index: number } | { kind: 'switch'; uid: string } | { kind: 'potion' } | { kind: 'orb' } | { kind: 'run' };

export interface Duel {
  tileId: string;
  encounterId: string;
  rng: number;
  turn: number;
  allies: Fighter[];
  enemies: Fighter[];
  ai: number; // 지금 나와 있는 아군
  ei: number; // 지금 나와 있는 적
  over: null | 'win' | 'lose' | 'run';
  needSwitch: boolean;
  /** 적별로 상대해 본 아군 (경험치 분배) */
  fought: Record<string, string[]>;
  xp: Record<string, number>; // 스피릿 id → 얻은 경험치
  used: { potion: number; orb: number };
  have: { potion: number; orb: number };
  captured: { species: string; level: number }[];
  log: DuelEvent[];
}

// ── 난수 (상태에 저장) ──
function rand(d: Duel): number {
  d.rng = (d.rng + 0x6d2b79f5) >>> 0;
  let t = d.rng;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

export const STATUS_LABEL: Record<Status, string> = { burn: '화상', poison: '중독', para: '마비' };
const STAT_LABEL: Record<Stat, string> = { atk: '공격', def: '방어', spd: '속도' };

/** 전투용 능력치 */
export function fighterStats(def: UnitDef, side: 'ally' | 'enemy', level: number, rank = 0, stage = 1, isBoss = false) {
  const g = BALANCE.growth;
  const lv = 1 + (side === 'ally' ? g.statPerLevel : BALANCE.enemy.statPerLevel) * (level - 1);
  const mul = lv * (1 + g.statPerRank * rank) * (side === 'ally' ? BALANCE.evolution.statMul[stage - 1] : 1);
  const D = BALANCE.duel;
  return {
    maxHp: Math.round(def.base.hp * mul * (isBoss ? D.bossHpMul : 1) * D.hpMul),
    atk: def.base.atk * mul,
    def: def.base.def * mul,
    res: (def.base.res ?? def.base.def) * mul,
    spd: def.base.spd * (1 + 0.02 * (level - 1)),
  };
}

const freshStages = (): Record<Stat, number> => ({ atk: 0, def: 0, spd: 0 });

export function allyFighter(id: string, sp: { level: number; rank: number; stage: number; moves?: string[] }): Fighter {
  const def = SPIRITS[id];
  const st = fighterStats(def, 'ally', sp.level, sp.rank, sp.stage);
  const moves = (sp.moves?.length ? sp.moves : defaultMoves(id, sp.level)).map((m) => ({ id: m, pp: MOVES[m].pp }));
  return {
    uid: `a:${id}`, side: 'ally', defId: id, species: id, name: def.stages?.[sp.stage - 1] ?? def.name, element: def.element,
    level: sp.level, stage: sp.stage, ...st, hp: st.maxHp, moves, stages: freshStages(), status: null, isBoss: false, xpYield: 0, gold: 0,
  };
}

export function enemyFighter(enemyId: string, level: number, i: number): Fighter {
  const def = ENEMIES[enemyId];
  const isBoss = !!def.isBoss;
  const st = fighterStats(def, 'enemy', level, 0, 1, isBoss);
  const learn = def.species ?? enemyId;
  const moves = defaultMoves(learn, level).map((m) => ({ id: m, pp: MOVES[m].pp }));
  const lvF = 1 + BALANCE.enemy.xpPerLevel * (level - 1);
  return {
    uid: `e:${i}:${enemyId}`, side: 'enemy', defId: enemyId, species: isBoss ? null : def.species ?? null, name: def.name, element: def.element,
    level, stage: 1, ...st, hp: st.maxHp, moves, stages: freshStages(), status: null, isBoss,
    xpYield: Math.round(def.xp * lvF * BALANCE.duel.xpMul * (isBoss ? 1.5 : 1)),
    gold: Math.round(def.gold * (1 + BALANCE.enemy.goldPerLevel * (level - 1))),
  };
}

/** 전투에 나오는 적: 보스는 마지막, 최대 BALANCE.duel.maxEnemies마리 */
export function duelEnemies(encounterId: string) {
  const enc = ENCOUNTERS[encounterId];
  const list = [...enc.enemies].sort((a, b) => Number(!!ENEMIES[a.enemyId].isBoss) - Number(!!ENEMIES[b.enemyId].isBoss));
  const boss = list.filter((e) => ENEMIES[e.enemyId].isBoss);
  const rest = list.filter((e) => !ENEMIES[e.enemyId].isBoss).slice(0, BALANCE.duel.maxEnemies - boss.length);
  return [...rest, ...boss];
}

export interface DuelInput {
  tileId: string;
  encounterId: string;
  seed: number;
  party: { id: string; level: number; rank: number; stage: number; moves?: string[] }[];
  potions: number;
  orbs: number;
}

export function createDuel(inp: DuelInput): Duel {
  const enemies = duelEnemies(inp.encounterId).map((e, i) => enemyFighter(e.enemyId, e.level, i));
  const allies = inp.party.map((p) => allyFighter(p.id, p));
  const d: Duel = {
    tileId: inp.tileId, encounterId: inp.encounterId, rng: inp.seed >>> 0, turn: 0, allies, enemies, ai: 0, ei: 0,
    over: null, needSwitch: false, fought: { [enemies[0].uid]: [allies[0].uid] }, xp: {}, used: { potion: 0, orb: 0 },
    have: { potion: inp.potions, orb: inp.orbs }, captured: [], log: [],
  };
  const e0 = enemies[0];
  d.log.push({ t: 'send', uid: e0.uid }, { t: 'msg', text: fixJosa(e0.isBoss ? `👑 보스 ${e0.name}이(가) 길을 막았다!` : `${e0.name} Lv.${e0.level}이(가) 덤벼든다!`) });
  d.log.push({ t: 'send', uid: allies[0].uid }, { t: 'msg', text: `${allies[0].name}, 나가자!` });
  return d;
}

export const activeAlly = (d: Duel) => d.allies[d.ai];
export const activeEnemy = (d: Duel) => d.enemies[d.ei];

function stageMul(s: number) {
  return s >= 0 ? (2 + s) / 2 : 2 / (2 - s);
}

function effSpeed(f: Fighter) {
  return f.spd * stageMul(f.stages.spd) * (f.status === 'para' ? 0.5 : 1);
}

/** 기대 피해 계산 (난수·급소 제외) — AI와 화면 표시용 */
export function estimate(att: Fighter, tgt: Fighter, mv: MoveDef) {
  if (mv.cat === 'status' || mv.power === 0) return { dmg: 0, type: 1, resisted: false };
  const A = att.atk * stageMul(att.stages.atk) * (att.status === 'burn' && mv.cat === 'phys' ? 0.5 : 1);
  const guard = (mv.cat === 'phys' ? tgt.def : tgt.res) * stageMul(tgt.stages.def);
  const K = BALANCE.battle.defK;
  const g = K / (K + guard);
  const type = mv.element ? elementMultiplier(mv.element, tgt.element) : 1;
  const stab = mv.element && mv.element === att.element ? BALANCE.duel.stab : 1;
  const dmg = (mv.power / 40) * A * BALANCE.duel.dmgMul * g * type * stab;
  return { dmg, type, resisted: g < 0.6 };
}

function push(d: Duel, out: DuelEvent[], e: DuelEvent) {
  out.push(e);
  d.log.push(e);
}

function msg(d: Duel, out: DuelEvent[], text: string) {
  push(d, out, { t: 'msg', text: fixJosa(text) });
}

function applyMove(d: Duel, out: DuelEvent[], att: Fighter, tgt: Fighter, slot: { id: string; pp: number }) {
  const mv = MOVES[slot.id];
  slot.pp = Math.max(0, slot.pp - 1);
  if (att.status === 'para' && rand(d) < 0.25) {
    msg(d, out, `찌릿! ${att.name}은(는) 몸이 굳어 움직이지 못했다.`);
    return;
  }
  push(d, out, { t: 'move', uid: att.uid, move: mv.id });
  msg(d, out, `${att.name} ▶ ${mv.name}`);
  const self = mv.effect && (mv.effect.kind === 'buff' || mv.effect.kind === 'heal');
  if (!self && rand(d) * 100 >= mv.acc) {
    msg(d, out, '공격이 빗나갔다!');
    return;
  }
  if (mv.cat !== 'status') {
    const est = estimate(att, tgt, mv);
    const crit = rand(d) < 1 / 16;
    const amount = Math.max(1, Math.round(est.dmg * (crit ? 1.5 : 1) * (0.85 + rand(d) * 0.15)));
    tgt.hp = Math.max(0, tgt.hp - amount);
    const eff = est.type > 1 ? 'super' : est.type < 1 ? 'weak' : null;
    push(d, out, { t: 'dmg', uid: tgt.uid, amount, hp: tgt.hp, eff, crit, resisted: est.resisted });
    if (crit) msg(d, out, '약점을 꿰뚫었다! (×1.5)');
    if (eff === 'super') msg(d, out, '상성 적중! 피해 ×2');
    if (eff === 'weak') msg(d, out, '상성이 나빠 피해가 반으로 줄었다… (×½)');
    if (est.resisted) msg(d, out, `${tgt.name}의 ${mv.cat === 'phys' ? '방어' : '마법방어'}가 대부분 막아 냈다!`);
    if (mv.effect?.kind === 'drain' && att.hp > 0) {
      const h = Math.min(att.maxHp - att.hp, Math.round(amount * mv.effect.ratio));
      if (h > 0) {
        att.hp += h;
        push(d, out, { t: 'heal', uid: att.uid, amount: h, hp: att.hp });
      }
    }
  }
  const e = mv.effect;
  if (!e) return;
  if (e.kind === 'status' && tgt.hp > 0 && !tgt.status && rand(d) * 100 < e.chance) {
    tgt.status = e.status;
    push(d, out, { t: 'status', uid: tgt.uid, status: e.status });
    msg(d, out, `${tgt.name}에게 ${STATUS_LABEL[e.status]}!`);
  } else if (e.kind === 'status' && mv.cat === 'status' && tgt.status) msg(d, out, '이미 상태이상이라 통하지 않았다.');
  if (e.kind === 'buff') {
    const before = att.stages[e.stat];
    att.stages[e.stat] = Math.min(6, before + e.stages);
    push(d, out, { t: 'stat', uid: att.uid, stat: e.stat, stages: e.stages });
    msg(d, out, before >= 6 ? '이미 한계까지 올랐다.' : `${att.name} ${STAT_LABEL[e.stat]} ▲${e.stages}`);
  }
  if (e.kind === 'debuff' && tgt.hp > 0 && rand(d) * 100 < e.chance) {
    tgt.stages[e.stat] = Math.max(-6, tgt.stages[e.stat] - e.stages);
    push(d, out, { t: 'stat', uid: tgt.uid, stat: e.stat, stages: -e.stages });
    msg(d, out, `${tgt.name} ${STAT_LABEL[e.stat]} ▼${e.stages}`);
  }
  if (e.kind === 'heal') {
    const h = Math.min(att.maxHp - att.hp, Math.round(att.maxHp * e.ratio));
    att.hp += h;
    push(d, out, { t: 'heal', uid: att.uid, amount: h, hp: att.hp });
    msg(d, out, h > 0 ? `${att.name} 체력 +${h}` : '체력이 이미 가득하다.');
  }
}

/** 기술 점수 (AI / 자동 전투) */
function scoreMove(att: Fighter, tgt: Fighter, slot: { id: string; pp: number }): number {
  if (slot.pp <= 0) return -1;
  const mv = MOVES[slot.id];
  const e = mv.effect;
  if (mv.cat !== 'status') {
    const est = estimate(att, tgt, mv);
    let sc = Math.min(est.dmg, tgt.hp * 1.05) * (mv.acc / 100);
    if (est.dmg >= tgt.hp && mv.priority) sc *= 1.3;
    if (e?.kind === 'drain') sc *= 1 + (1 - att.hp / att.maxHp) * 0.5;
    return sc;
  }
  const hpRatio = att.hp / att.maxHp;
  const ref = att.atk * 0.6;
  if (e?.kind === 'heal') return hpRatio < 0.45 ? ref * 2.2 : -1;
  if (e?.kind === 'status') return tgt.status ? -1 : ref * 0.8 * (tgt.hp / tgt.maxHp);
  if (e?.kind === 'buff') return att.stages[e.stat] >= 2 || hpRatio < 0.5 ? -1 : ref * (e.stat === 'spd' ? 0.6 : 0.85);
  if (e?.kind === 'debuff') return tgt.stages[e.stat] <= -2 ? -1 : ref * 0.5;
  return 0;
}

export function bestMoveIndex(att: Fighter, tgt: Fighter): number {
  let best = 0;
  let bs = -Infinity;
  att.moves.forEach((s, i) => {
    const sc = scoreMove(att, tgt, s);
    if (sc > bs) (bs = sc), (best = i);
  });
  return best;
}

function enemyChoice(d: Duel): number {
  const e = activeEnemy(d);
  const usable = e.moves.map((_, i) => i).filter((i) => e.moves[i].pp > 0);
  if (!usable.length) return -1;
  // 야생은 가끔 엉뚱한 기술을 쓴다
  if (!e.isBoss && rand(d) < 0.25) return usable[Math.floor(rand(d) * usable.length)];
  return bestMoveIndex(e, activeAlly(d));
}

/** 기술이 다 떨어졌을 때 쓰는 발버둥 */
const STRUGGLE = { id: 'tackle', pp: 99 };

function endOfTurn(d: Duel, out: DuelEvent[]) {
  for (const f of [activeAlly(d), activeEnemy(d)]) {
    if (f.hp <= 0 || !f.status || f.status === 'para') continue;
    const dmg = Math.max(1, Math.round(f.maxHp * (f.status === 'burn' ? 1 / 16 : 1 / 8)));
    f.hp = Math.max(0, f.hp - dmg);
    push(d, out, { t: 'dmg', uid: f.uid, amount: dmg, hp: f.hp, eff: null, crit: false, resisted: false });
    msg(d, out, `${f.name}: ${STATUS_LABEL[f.status]} 피해 -${dmg}`);
  }
}

function giveXp(d: Duel, out: DuelEvent[], enemy: Fighter) {
  // 싸운 동료는 전부, 파티의 나머지(기절 안 한) 동료는 절반 (경험치 나눔)
  const fought = d.fought[enemy.uid] ?? [];
  const names: string[] = [];
  for (const a of d.allies) {
    if (a.hp <= 0) continue;
    const amount = fought.includes(a.uid) ? enemy.xpYield : Math.round(enemy.xpYield * BALANCE.duel.benchXp);
    d.xp[a.defId] = (d.xp[a.defId] ?? 0) + amount;
    push(d, out, { t: 'xp', spiritId: a.defId, amount });
    if (fought.includes(a.uid)) names.push(a.name);
  }
  if (names.length) msg(d, out, `경험치 +${enemy.xpYield} (${names.join(', ')})`);
}

function handleFaints(d: Duel, out: DuelEvent[]) {
  const e = activeEnemy(d);
  if (e.hp <= 0 && !d.over) {
    if (!e.captured) {
      push(d, out, { t: 'faint', uid: e.uid });
      msg(d, out, `${e.name} 쓰러뜨림!`);
    }
    giveXp(d, out, e);
    if (d.ei + 1 < d.enemies.length) {
      d.ei++;
      const n = activeEnemy(d);
      d.fought[n.uid] = activeAlly(d).hp > 0 ? [activeAlly(d).uid] : [];
      push(d, out, { t: 'send', uid: n.uid });
      msg(d, out, n.isBoss ? `👑 보스 ${n.name} 등장!` : `다음 상대: ${n.name} Lv.${n.level}`);
    } else {
      d.over = 'win';
      msg(d, out, '전투 승리!');
    }
  }
  const a = activeAlly(d);
  if (a.hp <= 0 && !d.over) {
    push(d, out, { t: 'faint', uid: a.uid });
    msg(d, out, `${a.name}이(가) 쓰러졌다…`);
    if (d.allies.some((x) => x.hp > 0)) d.needSwitch = true;
    else {
      d.over = 'lose';
      msg(d, out, '파티가 모두 쓰러졌다… 일단 물러나자.');
    }
  }
}

function switchIn(d: Duel, out: DuelEvent[], uid: string) {
  const i = d.allies.findIndex((x) => x.uid === uid);
  const prev = activeAlly(d);
  if (prev.hp > 0) msg(d, out, `${prev.name}, 교대!`);
  prev.stages = freshStages();
  d.ai = i;
  const a = activeAlly(d);
  push(d, out, { t: 'send', uid: a.uid });
  msg(d, out, `${a.name}, 나가자!`);
  const f = (d.fought[activeEnemy(d).uid] ??= []);
  if (!f.includes(a.uid)) f.push(a.uid);
}

export function canCapture(d: Duel): boolean {
  const e = activeEnemy(d);
  return !!e.species && !e.isBoss && d.have.orb - d.used.orb > 0;
}

export function captureChance(e: Fighter): number {
  const p = (1 - (2 / 3) * (e.hp / e.maxHp)) * BALANCE.duel.captureRate * (e.status ? 1.5 : 1);
  return Math.max(0.05, Math.min(0.95, p));
}

/** 한 턴 진행. 이번 턴에 일어난 일을 돌려준다. */
export function doTurn(d: Duel, cmd: Command): DuelEvent[] {
  const out: DuelEvent[] = [];
  if (d.over || d.needSwitch) return out;
  d.turn++;
  const a = activeAlly(d);
  const e = activeEnemy(d);
  const eIdx = enemyChoice(d);
  const eSlot = eIdx >= 0 ? e.moves[eIdx] : STRUGGLE;

  if (cmd.kind === 'run') {
    if (e.isBoss) msg(d, out, '보스 앞에서는 물러날 수 없다!');
    else {
      d.over = 'run';
      msg(d, out, '한발 물러났다.');
      return out;
    }
  } else if (cmd.kind === 'switch') {
    switchIn(d, out, cmd.uid);
  } else if (cmd.kind === 'potion') {
    if (d.have.potion - d.used.potion <= 0) msg(d, out, '회복약이 없다!');
    else {
      d.used.potion++;
      const h = Math.min(a.maxHp - a.hp, Math.round(a.maxHp * BALANCE.duel.potionRatio));
      a.hp += h;
      push(d, out, { t: 'heal', uid: a.uid, amount: h, hp: a.hp });
      msg(d, out, `💊회복약: ${a.name} 체력 +${h}`);
    }
  } else if (cmd.kind === 'orb') {
    if (!canCapture(d)) msg(d, out, e.isBoss ? '보스는 봉인할 수 없다!' : '🔮결정이 없다!');
    else {
      d.used.orb++;
      msg(d, out, `🔮결정으로 봉인 시도!`);
      const p = captureChance(e);
      const each = Math.pow(p, 1 / 3);
      let shakes = 0;
      while (shakes < 3 && rand(d) < each) shakes++;
      const ok = shakes === 3;
      push(d, out, { t: 'capture', uid: e.uid, shakes, ok });
      if (ok) {
        e.captured = true;
        e.hp = 0;
        d.captured.push({ species: e.species!, level: e.level });
        msg(d, out, `봉인 성공! ${e.name}이(가) 결정에 깃들어 동료가 되었다!`);
        handleFaints(d, out);
        return out;
      }
      msg(d, out, ['결정이 튕겨 나갔다! 아직 기운이 넘친다.', '결정에 금이 갔다… 조금 더 약하게!', '봉인 직전에 깨졌다! 거의 다 됐다.'][Math.min(2, shakes)]);
    }
  }

  if (cmd.kind === 'move') {
    const aSlot = a.moves[cmd.index]?.pp > 0 ? a.moves[cmd.index] : a.moves.every((m) => m.pp <= 0) ? STRUGGLE : a.moves[cmd.index];
    const pa = MOVES[aSlot.id].priority ?? 0;
    const pe = MOVES[eSlot.id].priority ?? 0;
    const allyFirst = pa !== pe ? pa > pe : effSpeed(a) !== effSpeed(e) ? effSpeed(a) > effSpeed(e) : rand(d) < 0.5;
    const order: [Fighter, Fighter, { id: string; pp: number }][] = allyFirst
      ? [[a, e, aSlot], [e, a, eSlot]]
      : [[e, a, eSlot], [a, e, aSlot]];
    for (const [x, y, s] of order) {
      if (x.hp <= 0 || y.hp <= 0) continue;
      applyMove(d, out, x, y, s);
    }
  } else if (!d.over) {
    // 교체·아이템·포획 실패 뒤에는 적만 행동
    const cur = activeAlly(d);
    if (e.hp > 0 && cur.hp > 0) applyMove(d, out, e, cur, eSlot);
  }
  if (!d.over) {
    handleFaints(d, out);
    if (!d.over && !d.needSwitch) {
      endOfTurn(d, out);
      handleFaints(d, out);
    }
  }
  if (d.turn >= BALANCE.duel.maxTurns && !d.over) {
    d.over = 'lose';
    msg(d, out, '시간이 너무 흘렀다… 물러나자.');
  }
  return out;
}

/** 아군이 쓰러진 뒤 다음 동료 내보내기 */
export function forceSwitch(d: Duel, uid: string): DuelEvent[] {
  const out: DuelEvent[] = [];
  if (!d.needSwitch) return out;
  const i = d.allies.findIndex((x) => x.uid === uid && x.hp > 0);
  if (i < 0) return out;
  d.needSwitch = false;
  d.ai = i;
  const a = activeAlly(d);
  push(d, out, { t: 'send', uid: a.uid });
  msg(d, out, `${a.name}, 나가자!`);
  const f = (d.fought[activeEnemy(d).uid] ??= []);
  if (!f.includes(a.uid)) f.push(a.uid);
  return out;
}

/** 지금 적에게 가장 유리한 살아 있는 동료 */
export function bestSwitch(d: Duel, exclude?: string): string | null {
  const e = activeEnemy(d);
  const alive = d.allies.filter((x) => x.hp > 0 && x.uid !== exclude);
  if (!alive.length) return null;
  const score = (x: Fighter) => {
    const atk = Math.max(...x.moves.map((s) => (s.pp > 0 ? estimate(x, e, MOVES[s.id]).dmg : 0)));
    const def = Math.max(...e.moves.map((s) => estimate(e, x, MOVES[s.id]).dmg));
    return atk / Math.max(1, e.hp) - def / Math.max(1, x.hp);
  };
  return alive.sort((p, q) => score(q) - score(p))[0].uid;
}

/** 자동 전투: 양쪽 모두 가장 좋은 기술 (바로 결과 보기 / 시뮬레이션) */
export function autoCommand(d: Duel): Command {
  const a = activeAlly(d);
  const e = activeEnemy(d);
  if (a.hp / a.maxHp < 0.3 && d.have.potion - d.used.potion > 0 && e.hp / e.maxHp > 0.3) return { kind: 'potion' };
  return { kind: 'move', index: bestMoveIndex(a, e) };
}

export function autoDuel(d: Duel, opts: { capture?: boolean; owned?: string[] } = {}): Duel {
  for (let guard = 0; guard < 500 && !d.over; guard++) {
    if (d.needSwitch) forceSwitch(d, bestSwitch(d)!);
    else {
      const e = activeEnemy(d);
      const want = !opts.owned?.includes(e.species ?? '') && !d.captured.some((c) => c.species === e.species);
      if (opts.capture && want && canCapture(d) && e.hp / e.maxHp < 0.5) doTurn(d, { kind: 'orb' });
      else doTurn(d, autoCommand(d));
    }
  }
  return d;
}
