// 버전 관리되는 저장 데이터 (기획서 12장).
import { SAVE_VERSION, type GameState } from './game';

export const SAVE_KEY = 'hexa-frontier-v2/save';

export function serialize(s: GameState): string {
  return JSON.stringify(s);
}

export function deserialize(text: string): GameState | null {
  try {
    const raw = JSON.parse(text);
    return migrate(raw);
  } catch {
    return null;
  }
}

/** 버전별 마이그레이션. D68(v9)에서 전투·성장 방식이 통째로 바뀌어 이전 저장은 새 게임으로 시작한다. */
export function migrate(raw: any): GameState | null {
  if (!raw || typeof raw !== 'object' || typeof raw.version !== 'number') return null;
  if (raw.version !== SAVE_VERSION) return null;
  return raw as GameState;
}
