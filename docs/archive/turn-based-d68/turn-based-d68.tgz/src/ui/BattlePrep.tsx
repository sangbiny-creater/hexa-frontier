// 전투 준비 화면 (D68): 나올 적(속성·레벨·포획 가능) + 내 파티 순서(선두가 먼저 나감) + 바로 결과 보기.
import { useRef } from 'react';
import { ELEMENT_LABEL } from '../core/board';
import { duelEnemies } from '../core/duel';
import { difficultyOf, DIFFICULTY_LABEL, encounterLevel, makeLead, partyIds, respawnLeft, setParty, toggleParty, type GameState } from '../core/game';
import { attackMatchup, suggestTeam } from '../core/power';
import type { Element } from '../core/types';
import { ENCOUNTERS, ENEMIES } from '../data/enemies';
import { stageCode, TILE_BY_ID } from '../data/map';
import { SPIRITS } from '../data/spirits';
import { ELEMENT_COLOR, ELEMENT_ICON, enemyStage, GOLD, portrait, STONE } from './art';
import { DIFF_COLOR } from './MapView';
import { fmtDuration } from './store';

type Act = <T>(fn: (s: GameState, now: number) => T) => T;
const MATCH_LABEL = { adv: '▲ 유리', dis: '▼ 불리', even: '= 보통' } as const;

/** 길게 누르기 / 짧게 누르기 */
function usePress() {
  const timer = useRef<number | null>(null);
  const fired = useRef(false);
  const clear = () => {
    if (timer.current !== null) clearTimeout(timer.current);
    timer.current = null;
  };
  return (onLong: () => void, onTap?: () => void) => ({
    onPointerDown: () => {
      fired.current = false;
      clear();
      timer.current = window.setTimeout(() => ((fired.current = true), onLong()), 450);
    },
    onPointerUp: () => {
      const pending = timer.current !== null;
      clear();
      if (pending && !fired.current) onTap?.();
    },
    onPointerLeave: clear,
    onPointerCancel: clear,
    onContextMenu: (e: { preventDefault: () => void }) => e.preventDefault(),
  });
}

export function BattlePrep({
  state,
  tileId,
  now,
  guideText,
  focus,
  focusSuggest,
  act,
  toast,
  onGo,
  onClose,
  onElement,
}: {
  state: GameState;
  tileId: string;
  now: number;
  guideText?: string | null;
  focus: boolean;
  focusSuggest: boolean;
  act: Act;
  toast: (m: string) => void;
  onGo: () => void;
  onClose: () => void;
  onElement: (el: Element) => void;
}) {
  const t = TILE_BY_ID[tileId];
  const enc = ENCOUNTERS[t.encounterId!];
  const foes = duelEnemies(enc.id);
  const press = usePress();
  const cleared = state.cleared.includes(tileId);
  const left = cleared ? respawnLeft(state, tileId, now) : 0;
  const diff = difficultyOf(state, enc.id);
  const party = partyIds(state);
  const owned = Object.keys(state.spirits).sort((a, b) => state.spirits[b].level - state.spirits[a].level);
  const best = suggestTeam(owned, enc.id, state.maxDeploy, (id) => state.spirits[id].level);
  const bestIsOn = best.join() === party.join();
  const gold = foes.reduce((a, e) => a + Math.round(ENEMIES[e.enemyId].gold * (1 + 0.1 * (e.level - 1))), 0) + (cleared ? 0 : enc.firstClear.gold);
  const code = stageCode(t);

  return (
    <div className="screen prep">
      <div className="prep-top">
        <div className="prep-title">
          {code && <small className="stage-code">{code}</small>}
          <b>{t.name}</b>
          {enc.bossKind && <span className="boss-badge">BOSS</span>}
        </div>
        <button className="icon-btn" onClick={onClose} aria-label="닫기">
          ✕
        </button>
      </div>

      <div className="prep-body">
        {guideText && <div className="prep-guide">{guideText}</div>}
        <h4 className="sec-sm">나오는 적 (한 마리씩, 위에서부터)</h4>
        <div className="foe-list">
          {foes.map((e, i) => {
            const d = ENEMIES[e.enemyId];
            return (
              <div key={i} className="foe" {...press(() => onElement(d.element), () => onElement(d.element))}>
                <img src={portrait(d, enemyStage(d, e.level))} alt="" />
                <div className="foe-body">
                  <b>
                    {d.name} <small>Lv.{e.level}</small>
                  </b>
                  <span style={{ color: ELEMENT_COLOR[d.element] }}>
                    {ELEMENT_ICON[d.element]} {ELEMENT_LABEL[d.element]}
                  </span>
                  {(d.base.res ?? d.base.def) > d.base.def * 2 && <span className="foe-tag">🛡마법에 강함 → ⚔️물리로</span>}
                </div>
                {d.isBoss ? <span className="boss-badge">BOSS</span> : d.species ? <span className="catch-tag">🔮잡을 수 있음</span> : null}
              </div>
            );
          })}
          <div className="muted tiny center">적을 누르면 그 속성의 상성표</div>
        </div>

        <h4 className="sec-sm">
          내 파티 {party.length}/{state.maxDeploy} <span className="muted small">— 1번이 먼저 나가요. 누르면 선두로</span>
        </h4>
        <div className="party-list">
          {owned.map((id) => {
            const sp = state.spirits[id];
            const idx = party.indexOf(id);
            const m = attackMatchup(id, enc.id);
            return (
              <div key={id} className={`pmember ${idx >= 0 ? 'on' : ''}`}>
                <button className="pm-main" onClick={() => act((s) => makeLead(s, id))}>
                  <span className="pm-no">{idx >= 0 ? idx + 1 : '–'}</span>
                  <img src={portrait(SPIRITS[id], sp.stage)} alt="" />
                  <span className="pm-name">
                    {ELEMENT_ICON[SPIRITS[id].element]} {SPIRITS[id].stages?.[sp.stage - 1]} <small>Lv.{sp.level}</small>
                  </span>
                  <span className={`m-match ${m}`}>{MATCH_LABEL[m]}</span>
                </button>
                <button
                  className="pm-toggle"
                  onClick={() => {
                    const err = act((s) => toggleParty(s, id));
                    if (err) toast(err);
                  }}
                >
                  {idx >= 0 ? '빼기' : '넣기'}
                </button>
              </div>
            );
          })}
        </div>
        {owned.length > 1 && !bestIsOn && (
          <button className={`suggest ${focusSuggest ? 'pulse' : ''}`} onClick={() => act((s) => setParty(s, best))}>
            ✨ 추천 파티 (상성 + 레벨)
          </button>
        )}

        <div className="power-compare">
          <div className="pc-row">
            <span>적 최고 레벨</span>
            <b>Lv.{encounterLevel(enc.id)}</b>
          </div>
          <div className="pc-row">
            <span>내 파티 최고 레벨</span>
            <b style={{ color: DIFF_COLOR[diff] }}>
              Lv.{Math.max(...party.map((id) => state.spirits[id].level))} · {DIFFICULTY_LABEL[diff]}
            </b>
          </div>
        </div>
        <div className="reward-line">
          승리 보상 {GOLD} 약 {gold}
          {!cleared && enc.firstClear.stones > 0 && ` · ${STONE} ${enc.firstClear.stones}`}
          {!cleared && enc.firstClear.summon ? ` · 🔮 ${enc.firstClear.summon}` : ''} · 💊{state.items.potion} 🔮{state.summonStones}
        </div>
      </div>

      <div className="prep-foot">
        <label className="skip-check">
          <input type="checkbox" checked={state.settings.skipBattle} onChange={(e) => act((s) => (s.settings.skipBattle = e.target.checked))} />
          바로 결과 보기 (자동 전투)
        </label>
        <button className={`cta ${focus && !left ? 'pulse' : ''}`} disabled={left > 0} onClick={onGo}>
          {left > 0 ? `⏳ 다시 나타나기까지 ${fmtDuration(left)}` : cleared ? '다시 싸우기 (경험치 벌기)' : enc.bossKind ? '보스 도전' : '전투 시작'}
        </button>
      </div>
    </div>
  );
}
