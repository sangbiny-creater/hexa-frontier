// 전투 결과: 골드·경험치(레벨업)·새 기술·포획한 동료. 지면 해결 방법 버튼.
import { useEffect, useState } from 'react';
import type { Duel } from '../core/duel';
import { bestFarmTile, type DuelSummary, type GameState } from '../core/game';
import { xpToNext } from '../core/growth';
import { TILE_BY_ID } from '../data/map';
import { MOVES } from '../data/moves';
import { SPIRITS } from '../data/spirits';
import { Bar, GOLD, portrait, STONE } from './art';

export type ResultAction = 'farm' | 'party' | 'shop' | 'map';

export function ResultView({
  state,
  duel,
  sum,
  now,
  tip,
  onAction,
}: {
  state: GameState;
  duel: Duel;
  sum: DuelSummary;
  now: number;
  tip?: string | null;
  onAction: (a: ResultAction, tileId?: string) => void;
}) {
  const [gold, setGold] = useState(0);
  useEffect(() => {
    let v = 0;
    const id = setInterval(() => {
      v = Math.min(sum.gold, v + Math.max(1, Math.ceil(sum.gold / 20)));
      setGold(v);
      if (v >= sum.gold) clearInterval(id);
    }, 30);
    return () => clearInterval(id);
  }, [sum.gold]);
  const farm = sum.won ? null : bestFarmTile(state, now);
  const title = sum.won ? 'VICTORY' : sum.result === 'run' ? '도망쳤다' : 'DEFEAT';

  return (
    <div className="screen result-screen">
      <div className={`result-title ${sum.won ? 'win' : 'lose'}`}>{title}</div>
      <div className="loot">
        <div className="loot-item">
          <span className="big">{GOLD}</span>
          <b>+{gold}</b>
        </div>
        {sum.stones > 0 && (
          <div className="loot-item">
            <span className="big">{STONE}</span>
            <b>+{sum.stones}</b>
          </div>
        )}
        {sum.summon > 0 && (
          <div className="loot-item">
            <span className="big">🔮</span>
            <b>+{sum.summon}</b>
          </div>
        )}
      </div>
      {sum.firstClear && <div className="first">첫 승리 보너스!</div>}

      {sum.captured.map((c) => (
        <div key={c.id} className="caught">
          <img src={portrait(SPIRITS[c.id], 1)} alt="" />
          <div>
            <b>{c.isNew ? '🔮 새 동료!' : '🔮 같은 동료를 또 잡았다'}</b>
            <div>
              {SPIRITS[c.id].name} Lv.{c.level} {c.isNew ? '— 🐾스피릿 탭에서 파티에 넣을 수 있어요' : '→ 경험치로 바뀌었어요'}
            </div>
          </div>
        </div>
      ))}

      <div className="xp-list">
        {sum.xp.map((x) => {
          const sp = state.spirits[x.id];
          const learned = sum.learned.find((l) => l.id === x.id);
          return (
            <div key={x.id} className="xp-row">
              <img src={portrait(SPIRITS[x.id], sp.stage)} alt="" />
              <div className="xp-body">
                <div>
                  <b>{SPIRITS[x.id].stages?.[sp.stage - 1]}</b> <span className="muted small">경험치 +{x.gained}</span>
                  {x.to > x.from && <span className="lvup"> Lv.{x.from} → {x.to}!</span>}
                </div>
                <Bar value={sp.xp} max={xpToNext(sp.level)} color="#7ab8ff" h={6} />
                {learned && <div className="learned">✨ 새 기술: {learned.moves.map((m) => MOVES[m].name).join(', ')}</div>}
              </div>
            </div>
          );
        })}
        {!sum.xp.length && <div className="muted small center">경험치를 얻지 못했어요 (적을 쓰러뜨리거나 잡아야 해요)</div>}
      </div>

      {sum.unlocked.map((u) => (
        <div key={u} className="unlock">
          🔓 {u}
        </div>
      ))}
      {tip && <div className="tip inline">{tip}</div>}

      {sum.won || sum.result === 'run' ? (
        <button className="cta" onClick={() => onAction('map')}>
          계속
        </button>
      ) : (
        <div className="fix-list">
          <div className="muted small center">
            적 {duel.enemies.filter((e) => e.hp > 0).length}마리 남음. 이렇게 해 보세요:
          </div>
          <button className="fix" onClick={() => onAction('party')}>
            <b>🔄 파티·순서 바꾸기</b>
            <small>상성이 좋은 동료(▲)를 선두로! 적 속성에 강한 기술이 있는 동료를 내보내요.</small>
          </button>
          {farm && (
            <button className="fix" onClick={() => onAction('farm', farm)}>
              <b>⭐ 경험치 벌러 가기 ({TILE_BY_ID[farm].name})</b>
              <small>이미 이긴 칸에서 다시 싸워 레벨을 올려요. 레벨이 오르면 새 기술도 배워요.</small>
            </button>
          )}
          <button className="fix" onClick={() => onAction('shop')}>
            <b>💊 회복약 준비</b>
            <small>전투 중 🎒가방 → 회복약으로 체력 50% 회복. 🏕캠프 상점에서 살 수 있어요 (지금 {state.items.potion}개).</small>
          </button>
          <button className="ghost" onClick={() => onAction('map')}>
            지도로
          </button>
        </div>
      )}
    </div>
  );
}
