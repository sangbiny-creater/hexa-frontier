// 튜토리얼 (D68): 모험가 '아렌'이 처음 하는 사람에게 한 가지씩 알려 준다.
// 지도 안내(computeGuide) + 전투 중 안내(battleHint) + 한 번씩 뜨는 설명 팝업(lessonDue).
import { activeAlly, activeEnemy, bestSwitch, estimate, type Duel } from '../core/duel';
import { bestFarmTile, encounterLevel, partyIds, partyLevel, TUTORIAL_PATH, type GameState } from '../core/game';
import { suggestTeam } from '../core/power';
import { fixJosa } from '../core/text';
import { MOVES } from '../data/moves';
import { TILE_BY_ID } from '../data/map';
import { SPIRITS } from '../data/spirits';
import type { BattleHint } from './BattleView';
import { asset } from './art';

export type Tab = 'map' | 'spirit' | 'summon' | 'camp';
export type GuideTarget = { kind: 'tile'; id: string } | { kind: 'tileAction' } | { kind: 'tab'; tab: Tab } | { kind: 'suggest' } | null;

export interface Guide {
  text: string;
  target: GuideTarget;
  finish?: boolean;
}

const T = (s: string) => fixJosa(s);

export function computeGuide(state: GameState, ctx: { selected: string | null; tab: Tab; now?: number }): Guide | null {
  const tut = state.tutorial;
  if (!tut.introSeen || tut.done || state.map !== 'P00') return null;
  const now = ctx.now ?? state.lastTickAt;
  const c = (id: string) => state.cleared.includes(id);
  const atMap = (id: string, ask: string, press: string): Guide =>
    ctx.tab !== 'map'
      ? { text: '🗺탐험 탭으로 돌아가자!', target: { kind: 'tab', tab: 'map' } }
      : ctx.selected === id
        ? { text: T(press), target: { kind: 'tileAction' } }
        : { text: T(ask), target: { kind: 'tile', id } };

  const next = TUTORIAL_PATH.find((id) => !c(id));
  if (!next)
    return {
      text: '튜토리얼 끝! 정리하면 ① 상성 좋은 기술(×2) ② 불리하면 교체 ③ 약하게 만들고 🔮포획 ④ 위험하면 💊회복약 ⑤ 막히면 이긴 칸에서 경험치. 이제 맨 위 길로 본편 P01(스테이지 100개)!',
      target: null,
      finish: true,
    };

  // 여우를 못 잡고 지나갔으면: 다시 잡으러
  if (c('a3') && !state.spirits.tidekit && !c('a4')) {
    if (state.summonStones < 1) return ctx.tab !== 'camp' ? { text: '🔮봉인 결정이 없어! 🏕캠프 상점에서 사자.', target: { kind: 'tab', tab: 'camp' } } : { text: '상점에서 [🔮 봉인 결정]을 사!', target: null };
    return atMap('a3', '여우를 놓쳤어! 이긴 칸은 ⏳1분 뒤 몬스터가 다시 나타나. 다시 잡으러 가자.', '[다시 싸우기]! 체력을 줄이고 🔮구슬!');
  }
  // 골렘을 넘으면 캠프 소개 (한 번)
  if (c('b1') && !tut.seen.includes('camp')) return { text: '골렘을 넘었더니 🏕캠프가 열렸어! 자동 사냥(자리를 비워도 골드)과 상점(회복약·봉인 결정)이 있어. 한번 가 보자.', target: { kind: 'tab', tab: 'camp' } };

  const t = TILE_BY_ID[next];
  // 물안개 여울 전에 물리 공격 동료가 없으면: 늑대·멧돼지를 잡으러
  const PHYS = ['skywarden', 'rocky', 'leafpup', 'tideshell', 'galewing'];
  if ((next === 'c2' || next === 'c1') && c('b1') && !PHYS.some((id) => state.spirits[id])) {
    if (state.summonStones < 1) return ctx.tab !== 'camp' ? { text: '⚔️물리 공격 동료를 잡으려면 🔮구슬이 필요해. 🏕캠프 상점으로!', target: { kind: 'tab', tab: 'camp' } } : { text: '상점에서 [🔮 봉인 결정]을 사!', target: null };
    return atMap('a6', '물안개 여울은 ✨마법이 잘 안 통해. ⚔️물리 공격을 하는 🌪️돌풍 늑대를 잡으러 가자! (돌풍 언덕)', '[다시 싸우기]! 늑대의 체력을 줄이고 🔮구슬!');
  }
  // 진 칸: 파티 바꾸기 → 경험치 벌기 → 재도전
  if (t.encounterId && state.attempts[next]) {
    const best = suggestTeam(Object.keys(state.spirits), t.encounterId, state.maxDeploy, (id) => state.spirits[id].level);
    if (best.join() !== partyIds(state).join() && ctx.tab === 'map' && ctx.selected === next) return { text: '[✨추천 파티]로 상성이 좋은 동료를 앞에 세우자!', target: { kind: 'suggest' } };
    // 질수록 조금 더 강해진 뒤 재도전 (적 레벨 -1, 두 번 이상 지면 적 레벨까지)
    const need = encounterLevel(t.encounterId) - 1 + Math.min(1, state.attempts[next] - 1);
    const gap = need - partyLevel(state);
    if (gap > 0) {
      const farm = bestFarmTile(state, now);
      if (farm) return atMap(farm, `${t.name}은(는) Lv.${encounterLevel(t.encounterId)}. 우리 최고 Lv.${partyLevel(state)} → Lv.${need}까지 올리자! 이미 이긴 ▼${TILE_BY_ID[farm].name}에서 경험치를 벌자.`, '[다시 싸우기]! 싸운 동료만 경험치를 받아.');
      return { text: '이긴 칸은 ⏳1분 뒤 몬스터가 다시 나타나. 잠깐 기다렸다가 경험치를 벌자!', target: null };
    }
    return atMap(next, `준비됐어! ${t.name} 재도전. 위험하면 🎒가방 → 💊회복약을 잊지 마.`, '[전투 시작]!');
  }

  const lines: Record<string, [string, string]> = {
    a1: ['나는 모험가 아렌. 숲 꼭대기까지 가는 게 목표야! 내 동료는 🔥엠버 칙. 바로 위 칸(▼)을 눌러 봐.', '나올 적과 내 파티가 보이지? [전투 시작]!'],
    a2: ['이겼다! 반짝이는 덤불에 뭔가 있어.', '[줍기]! 🔮결정은 야생 몬스터를 잡는 봉인 결정이야.'],
    a3: ['아기 물결 여우(💧)야. 이번엔 쓰러뜨리지 말고 동료로 만들어 보자!', '[전투 시작]! 체력을 줄이고 🔮구슬을 던질 거야.'],
    a4: ['🔥불씨 둥지! 엠버 칙(🔥)은 같은 불끼리라 효과가 별로야. 💧물결 여우가 활약할 차례!', '[전투 시작]! 전투 중에 🔄교체를 써 보자.'],
    a5: ['약초 밭이야. 회복약을 챙기자.', '[줍기]!'],
    a6: ['돌풍 언덕엔 🌪️바람 늑대가 있어. 정전기에 맞으면 마비될 수도 있어!', '[전투 시작]! 체력이 줄면 💊회복약.'],
    a7: ['바위엄니 덤불(⛰️). 꽤 강해! 늑대·멧돼지도 잡을 수 있어.', '[전투 시작]!'],
    a8: ['신비한 결정이 잔뜩! ✨소환 탭이 열려. 결정 10개로 원하는 속성 동료를 부를 수 있어.', '[줍기]!'],
    b1: ['숲의 보스 고목 골렘(🌿)! 보스는 잡을 수도, 도망칠 수도 없어. 🌿숲에는 🔥불이 강해!', '보스 도전! 엠버 칙이 1번(선두)인지 확인!'],
    c1: ['버려진 야영지에 회복약이 남아 있어.', '[줍기]!'],
    c2: ['물안개 여울(💧). 이번엔 특별한 비밀이 있어. 물안개가 ✨마법을 막아!', '[전투 시작]! ⚔️물리 기술을 써 봐.'],
    c3: ['바위엄니 떼(⛰️·🌿). 배운 걸 다 써 보자!', '[전투 시작]!'],
    c4: ['바위 틈에 보물 상자!', '[열기]!'],
    b2: ['튜토리얼 마지막 보스, 바위엄니 대장(⛰️)! ⛰️대지에는 🌿숲이 강해.', '보스 도전!'],
  };
  const pair = lines[next] ?? [`▼ ${t.name}`, '버튼을 눌러!'];
  return atMap(next, pair[0], pair[1]);
}

/** 전투 중 안내 (튜토리얼 동안만) */
export function battleHint(state: GameState, d: Duel, menu: 'main' | 'moves' | 'switch' | 'bag'): BattleHint | null {
  if (state.tutorial.done || !state.tutorial.introSeen || state.map !== 'P00') return null;
  const a = activeAlly(d);
  const e = activeEnemy(d);
  if (d.needSwitch) {
    const b = bestSwitch(d);
    return { text: '쓰러졌어! 다음 동료를 골라. "유리!" 표시가 있으면 더 좋아.', focus: b ? `ally:${b.slice(2)}` : undefined };
  }
  const potions = d.have.potion - d.used.potion;
  const hpLow = a.hp / a.maxHp < 0.35 && e.hp / e.maxHp > 0.25;
  const bestMove = () => {
    let bi = 0;
    let bv = -1;
    a.moves.forEach((s, i) => {
      const v = s.pp > 0 ? estimate(a, e, MOVES[s.id]).dmg : -1;
      if (v > bv) (bv = v), (bi = i);
    });
    return a.moves[bi].id;
  };

  // 여우 잡기
  if (d.tileId === 'a3' && !state.spirits.tidekit && e.species === 'tidekit') {
    const low = e.hp / e.maxHp <= 0.5;
    if (low) return menu === 'bag' ? { text: '🔮봉인 결정! 결정이 세 번 빛나면 성공!', focus: 'orb' } : { text: T(`${e.name}의 체력이 절반 아래! 지금이야: 🎒가방 → 🔮봉인 결정`), focus: 'bag' };
    if (menu === 'moves') return { text: '🔥불씨는 💧물에게 별로(×½). 무속성 [날쌘 발걸음]로 살살 체력을 줄이자!', focus: 'move:quick' };
    if (menu === 'bag') return { text: '아직 체력이 많으면 잘 안 잡혀. ← 뒤로 → 기술로 체력부터!', focus: undefined };
    return { text: '먼저 [⚔️기술]로 체력을 절반 아래로 줄이자.', focus: 'fight' };
  }
  // 아직 없는 야생 몬스터: 잡아 보자 (구슬이 있을 때)
  const orbs = d.have.orb - d.used.orb;
  if (e.species && !e.isBoss && !state.spirits[e.species] && !d.captured.some((x) => x.species === e.species) && orbs > 0 && !(hpLow && potions > 0)) {
    const low = e.hp / e.maxHp <= 0.5;
    const name = SPIRITS[e.species].name;
    if (low) return menu === 'bag' ? { text: '🔮봉인 결정!', focus: 'orb' } : { text: T(`${name}을(를) 잡을 기회! 🎒가방 → 🔮봉인 결정`), focus: 'bag' };
    if (menu === 'moves') {
      let bi = 0;
      let bv = Infinity;
      a.moves.forEach((s, i) => {
        const v = s.pp > 0 && MOVES[s.id].cat !== 'status' ? estimate(a, e, MOVES[s.id]).dmg : Infinity;
        if (v < bv) (bv = v), (bi = i);
      });
      return { text: T(`${name}도 동료로 만들 수 있어! 약한 기술로 체력을 절반 아래로 줄이자.`), focus: `move:${a.moves[bi].id}` };
    }
    if (menu === 'main') return { text: T(`야생 ${name}! 체력을 줄이면 🔮구슬로 잡을 수 있어.`), focus: 'fight' };
  }
  if (hpLow && potions > 0) return menu === 'bag' ? { text: '💊회복약! 한 턴을 쓰지만 체력이 50% 회복돼.', focus: 'potion' } : { text: '체력이 위험해! 🎒가방 → 💊회복약', focus: 'bag' };
  // 불씨 둥지: 교체 배우기
  if (d.tileId === 'a4' && a.element === 'fire' && e.element === 'fire') {
    const fox = d.allies.find((x) => x.defId === 'tidekit' && x.hp > 0);
    if (fox) return menu === 'switch' ? { text: '💧물결 여우를 내보내!', focus: 'ally:tidekit' } : { text: '🔥끼리는 효과가 별로야. [🔄교체]로 💧물결 여우를 내보내자! (교체하면 한 턴을 써)', focus: 'switch' };
  }
  // 물안개 여울: 물리 기술
  if (d.tileId === 'c2') {
    const phys = a.moves.find((s) => MOVES[s.id].cat === 'phys' && s.pp > 0);
    if (menu === 'moves')
      return phys ? { text: T(`물안개 여우는 ✨마법방어가 아주 높아. ⚔️물리 기술 [${MOVES[phys.id].name}]이 잘 들어!`), focus: `move:${bestMove()}` } : { text: '이 동료는 물리 기술이 없어. ← 뒤로 → 🔄교체로 ⚔️물리 기술이 있는 동료를!', focus: undefined };
    return { text: '⚔️물리 기술을 쓰자! 마법은 "막힘"이 떠.', focus: 'fight' };
  }
  if (menu === 'moves') {
    const id = bestMove();
    const est = estimate(a, e, MOVES[id]);
    return { text: est.type > 1 ? T(`[${MOVES[id].name}]! "상성 ×2" 표시가 있는 기술이 가장 세.`) : '기술 색은 속성이야. 상대 속성에 강한 기술을 골라!', focus: `move:${id}` };
  }
  if (menu === 'main') return { text: d.tileId === 'a1' ? '[⚔️기술]을 눌러 공격할 기술을 골라!' : '[⚔️기술]로 공격! 불리하면 🔄교체, 위험하면 🎒가방.', focus: 'fight' };
  return null;
}

/** 한 번씩 뜨는 설명 팝업 */
export type LessonId = 'type' | 'capture' | 'boss' | 'magic' | 'evolve';
export function lessonDue(state: GameState): LessonId | null {
  const tut = state.tutorial;
  if (!tut.introSeen || tut.done || state.map !== 'P00') return null;
  const seen = (id: string) => tut.seen.includes(id);
  const c = (id: string) => state.cleared.includes(id);
  if (c('a1') && !seen('type')) return 'type';
  if (Object.keys(state.spirits).length > 1 && !seen('capture')) return 'capture';
  if (c('a8') && !c('b1') && !seen('boss')) return 'boss';
  if (c('c1') && !c('c2') && !seen('magic')) return 'magic';
  if (Object.values(state.spirits).some((s) => s.stage > 1) && !seen('evolve')) return 'evolve';
  return null;
}

export { SPIRITS };

export function GuideBar({ guide, onFinish, onSkip }: { guide: Guide; onFinish: () => void; onSkip: () => void }) {
  return (
    <div className="guide">
      <img className="guide-face" src={asset('hero-p')} alt="아렌" />
      <div className="guide-body">
        <div className="guide-text">{guide.text}</div>
        <div className="guide-actions">
          {guide.finish ? (
            <button className="cta small-cta" onClick={onFinish}>
              알겠어!
            </button>
          ) : (
            <button className="link" onClick={onSkip}>
              튜토리얼 건너뛰기
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export function Intro({ hasProgress, onStart, onContinue, onClose }: { hasProgress: boolean; onStart: () => void; onContinue?: () => void; onClose?: () => void }) {
  return (
    <div className="screen intro">
      <img className="intro-hero" src={asset('hero-t')} alt="" />
      <div className="intro-logo">
        HEXA <span>FRONTIER</span>
      </div>
      <div className="intro-sub">작은 헥사, 넓은 세계</div>
      <ol className="intro-steps">
        <li>
          <span>🗺</span>
          <div>
            <b>헥사 지도를 탐험</b>
            <p>칸을 누르면 주인공이 걸어가고, 몬스터를 만나면 전투!</p>
          </div>
        </li>
        <li>
          <span>⚔️</span>
          <div>
            <b>턴제 기술 배틀</b>
            <p>매 턴 기술을 골라요. 💧물→🔥불→🌿숲→⛰️대지→🌪️바람→💧물, 상성이 맞으면 피해 ×2!</p>
          </div>
        </li>
        <li>
          <span>🔮</span>
          <div>
            <b>잡고, 키우고, 진화</b>
            <p>야생 몬스터를 약하게 만들어 잡고, 경험치로 레벨업·새 기술·진화. 튜토리얼(P00) 다음엔 P01-001~100!</p>
          </div>
        </li>
      </ol>
      {onClose ? (
        <button className="cta" onClick={onClose}>
          닫기
        </button>
      ) : (
        <>
          <button className="cta" onClick={onStart}>
            {hasProgress ? '처음부터 시작' : '모험 시작'}
          </button>
          {hasProgress && onContinue && (
            <button className="ghost" onClick={onContinue}>
              이어서 하기
            </button>
          )}
        </>
      )}
    </div>
  );
}
