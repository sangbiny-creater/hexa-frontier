// 턴제 전투 화면 (D68). 위쪽 = 적, 아래쪽 = 내 동료. 아래 메시지 창 + [기술/교체/가방/도망].
// 한 턴의 일(DuelEvent)을 차례로 재생하며 체력 바·피해 숫자·봉인 결정을 움직인다.
import { useEffect, useRef, useState } from 'react';
import { ELEMENT_LABEL } from '../core/board';
import {
  activeAlly,
  activeEnemy,
  autoCommand,
  autoDuel,
  bestSwitch,
  canCapture,
  captureChance,
  doTurn,
  estimate,
  forceSwitch,
  STATUS_LABEL,
  type Command,
  type Duel,
  type DuelEvent,
  type Fighter,
} from '../core/duel';
import { ENEMIES } from '../data/enemies';
import { TILE_BY_ID } from '../data/map';
import { MOVES } from '../data/moves';
import { SPIRITS } from '../data/spirits';
import { ELEMENT_COLOR, ELEMENT_ICON, enemyStage, sprite } from './art';

export interface BattleHint {
  text: string;
  /** 반짝일 버튼: fight / bag / switch / run / move:<id> / orb / potion / ally:<spiritId> */
  focus?: string;
}

type Menu = 'main' | 'moves' | 'switch' | 'bag';

const CAT_ICON = { phys: '⚔️', magic: '✨', status: '◇' } as const;
const CAT_LABEL = { phys: '물리', magic: '마법', status: '변화' } as const;

function fighterSprite(f: Fighter) {
  if (f.side === 'ally') return sprite(SPIRITS[f.defId], f.stage);
  const def = ENEMIES[f.defId];
  return sprite(def, enemyStage(def, f.level));
}

export function BattleView({
  duel: initial,
  instant,
  hint,
  onFinish,
}: {
  duel: Duel;
  instant?: boolean;
  hint?: (d: Duel, menu: Menu) => BattleHint | null;
  onFinish: (d: Duel) => void;
}) {
  const [d, setD] = useState<Duel>(() => (instant ? autoDuel(structuredClone(initial)) : initial));
  const [menu, setMenu] = useState<Menu>('main');
  const [queue, setQueue] = useState<DuelEvent[]>(() => (instant ? [] : initial.log.slice()));
  const [text, setText] = useState('');
  const [hp, setHp] = useState<Record<string, number>>(() => Object.fromEntries([...initial.allies, ...initial.enemies].map((f) => [f.uid, f.maxHp])));
  const [shown, setShown] = useState<{ ally: string; enemy: string }>({ ally: initial.allies[0].uid, enemy: initial.enemies[0].uid });
  const [fx, setFx] = useState<{ uid: string; kind: string; text?: string; key: number } | null>(null);
  const [fainted, setFainted] = useState<Set<string>>(new Set());
  const [orb, setOrb] = useState<{ shakes: number; ok: boolean; step: number } | null>(null);
  const [auto, setAuto] = useState(false);
  const fast = useRef(false);
  const playing = queue.length > 0;

  // 바로 결과 보기: 자동으로 끝까지 싸운 뒤 바로 결과로
  useEffect(() => {
    if (instant) onFinish(d);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // 이벤트 하나씩 재생
  useEffect(() => {
    if (!queue.length) return;
    const [ev, ...rest] = queue;
    let wait = 0;
    const k = Date.now();
    switch (ev.t) {
      case 'msg':
        setText(ev.text);
        wait = 900;
        break;
      case 'send':
        setFainted((s) => {
          const n = new Set(s);
          n.delete(ev.uid);
          return n;
        });
        setShown((s) => (ev.uid.startsWith('a:') ? { ...s, ally: ev.uid } : { ...s, enemy: ev.uid }));
        setFx({ uid: ev.uid, kind: 'send', key: k });
        wait = 350;
        break;
      case 'move':
        setFx({ uid: ev.uid, kind: 'act', key: k });
        wait = 250;
        break;
      case 'dmg':
        setHp((h) => ({ ...h, [ev.uid]: ev.hp }));
        setFx({ uid: ev.uid, kind: ev.eff === 'super' ? 'hit super' : ev.eff === 'weak' || ev.resisted ? 'hit weak' : 'hit', text: `-${ev.amount}`, key: k });
        wait = 650;
        break;
      case 'heal':
        setHp((h) => ({ ...h, [ev.uid]: ev.hp }));
        setFx({ uid: ev.uid, kind: 'heal', text: `+${ev.amount}`, key: k });
        wait = 550;
        break;
      case 'status':
      case 'stat':
        setFx({ uid: ev.uid, kind: ev.t === 'stat' ? (ev.stages > 0 ? 'up' : 'down') : 'status', key: k });
        wait = 300;
        break;
      case 'faint':
        setFainted((s) => new Set(s).add(ev.uid));
        wait = 500;
        break;
      case 'capture':
        setOrb({ shakes: ev.shakes, ok: ev.ok, step: 0 });
        wait = 700 + ev.shakes * 550;
        break;
      case 'xp':
        wait = 0;
        break;
    }
    if (fast.current) wait = Math.min(wait, 160);
    const id = setTimeout(() => {
      if (ev.t === 'capture') {
        setOrb(null);
        if (ev.ok) setFainted((s) => new Set(s).add(ev.uid));
      }
      setQueue(rest);
    }, wait);
    return () => clearTimeout(id);
  }, [queue]);

  // 봉인 결정 흔들림 단계
  useEffect(() => {
    if (!orb || orb.step >= orb.shakes) return;
    const id = setTimeout(() => setOrb((o) => (o ? { ...o, step: o.step + 1 } : o)), 550);
    return () => clearTimeout(id);
  }, [orb]);

  // 재생이 끝나면: 끝났으면 결과로, 자동이면 다음 턴
  useEffect(() => {
    if (playing || instant) return;
    fast.current = false;
    if (d.over) {
      const id = setTimeout(() => onFinish(d), 700);
      return () => clearTimeout(id);
    }
    if (auto) {
      const id = setTimeout(() => (d.needSwitch ? pickSwitch(bestSwitch(d)!) : run(autoCommand(d))), 300);
      return () => clearTimeout(id);
    }
  }, [playing, d, auto]); // eslint-disable-line react-hooks/exhaustive-deps

  const run = (cmd: Command) => {
    const nd = structuredClone(d);
    const evs = doTurn(nd, cmd);
    setD(nd);
    setMenu('main');
    setQueue(evs);
  };
  const pickSwitch = (uid: string) => {
    const nd = structuredClone(d);
    const evs = d.needSwitch ? forceSwitch(nd, uid) : doTurn(nd, { kind: 'switch', uid });
    setD(nd);
    setMenu('main');
    setQueue(evs);
  };

  const a = d.allies.find((x) => x.uid === shown.ally)!;
  const e = d.enemies.find((x) => x.uid === shown.enemy)!;
  const cur = activeAlly(d);
  const foe = activeEnemy(d);
  const h = !playing && !d.over && !auto && hint ? hint(d, d.needSwitch ? 'switch' : menu) : null;
  const pulse = (k: string) => (h?.focus === k ? 'pulse' : '');
  const tile = TILE_BY_ID[d.tileId];

  return (
    <div className="screen duel">
      <div className="duel-top">
        <b>{tile?.name}</b>
        {foe.isBoss && <span className="boss-badge">BOSS</span>}
        <span className="duel-count">
          적 {d.enemies.filter((x) => x.hp > 0).length}/{d.enemies.length}
        </span>
        <button className={`auto-btn ${auto ? 'on' : ''}`} onClick={() => setAuto(!auto)}>
          {auto ? '자동 ON' : '자동'}
        </button>
      </div>

      <div className="field" onClick={() => (fast.current = true)}>
        <div className="hexgrid" />
        <span className="vs">VS</span>
        <InfoCard f={e} hp={hp[e.uid]} side="enemy" />
        <div className={`mon enemy ${fainted.has(e.uid) ? 'gone' : ''} ${fx?.uid === e.uid ? fx.kind : ''}`} key={`e${e.uid}${fx?.uid === e.uid ? fx.key : ''}`}>
          <img src={fighterSprite(e)} alt={e.name} draggable={false} />
          {fx?.uid === e.uid && fx.text && <span className={`dmg-float ${fx.kind}`}>{fx.text}</span>}
        </div>
        <div className={`mon ally ${fainted.has(a.uid) ? 'gone' : ''} ${fx?.uid === a.uid ? fx.kind : ''}`} key={`a${a.uid}${fx?.uid === a.uid ? fx.key : ''}`}>
          <img src={fighterSprite(a)} alt={a.name} draggable={false} />
          {fx?.uid === a.uid && fx.text && <span className={`dmg-float ${fx.kind}`}>{fx.text}</span>}
        </div>
        <InfoCard f={a} hp={hp[a.uid]} side="ally" />
        {orb && (
          <div className={`orb ${orb.step < orb.shakes ? 'shake' : ''} ${orb.step >= orb.shakes ? (orb.ok ? 'ok' : 'fail') : ''}`} key={orb.step}>
            🔮
          </div>
        )}
      </div>

      <div className="duel-bottom">
        <div className="msgbox" onClick={() => (fast.current = true)}>
          {text || ' '}
          {playing && <span className="msg-more">▼</span>}
        </div>
        {h && (
          <div className="duel-hint">
            <b>아렌</b> {h.text}
          </div>
        )}
        {!playing && !d.over && !auto && (
          <>
            {d.needSwitch ? (
              <SwitchList d={d} onPick={pickSwitch} forced pulse={pulse} />
            ) : menu === 'main' ? (
              <div className="cmd-grid">
                <button className={`cmd fight ${pulse('fight')}`} onClick={() => setMenu('moves')}>
                  ⚔️ 기술
                </button>
                <button className={`cmd ${pulse('switch')}`} onClick={() => setMenu('switch')} disabled={d.allies.filter((x) => x.hp > 0).length < 2}>
                  🔄 교체
                </button>
                <button className={`cmd ${pulse('bag')}`} onClick={() => setMenu('bag')}>
                  🎒 가방
                </button>
                <button className={`cmd ${pulse('run')}`} onClick={() => run({ kind: 'run' })} disabled={foe.isBoss}>
                  🏃 도망
                </button>
              </div>
            ) : menu === 'moves' ? (
              <div className="cmd-grid moves">
                {cur.moves.map((s, i) => {
                  const mv = MOVES[s.id];
                  const est = estimate(cur, foe, mv);
                  const tag = mv.cat === 'status' ? '' : est.type > 1 ? '상성 ×2' : est.type < 1 ? '상성 ×½' : est.resisted ? '막힘' : '';
                  const col = mv.element ? ELEMENT_COLOR[mv.element] : '#9aa5a0';
                  return (
                    <button
                      key={s.id}
                      className={`move-btn ${pulse(`move:${s.id}`)}`}
                      style={{ borderColor: col, background: col + '26' }}
                      disabled={s.pp <= 0}
                      onClick={() => run({ kind: 'move', index: i })}
                    >
                      <b>{mv.name}</b>
                      <span className="mv-meta">
                        {mv.element ? `${ELEMENT_ICON[mv.element]}${ELEMENT_LABEL[mv.element]}` : '무속성'} · {CAT_ICON[mv.cat]}
                        {CAT_LABEL[mv.cat]} · {s.pp}/{mv.pp}
                      </span>
                      {tag && <span className={`mv-tag ${est.type > 1 ? 'adv' : 'dis'}`}>{tag}</span>}
                    </button>
                  );
                })}
                <button className="cmd back" onClick={() => setMenu('main')}>
                  ← 뒤로
                </button>
              </div>
            ) : menu === 'switch' ? (
              <SwitchList d={d} onPick={pickSwitch} onBack={() => setMenu('main')} pulse={pulse} />
            ) : (
              <div className="cmd-grid bag">
                <button className={`bag-btn ${pulse('potion')}`} disabled={d.have.potion - d.used.potion <= 0 || cur.hp >= cur.maxHp} onClick={() => run({ kind: 'potion' })}>
                  <b>💊 회복약 ×{d.have.potion - d.used.potion}</b>
                  <small>체력 50% 회복 (한 턴 사용)</small>
                </button>
                <button className={`bag-btn ${pulse('orb')}`} disabled={!canCapture(d)} onClick={() => run({ kind: 'orb' })}>
                  <b>🔮 봉인 결정 ×{d.have.orb - d.used.orb}</b>
                  <small>{foe.isBoss ? '보스는 잡을 수 없어요' : !foe.species ? '잡을 수 없는 적' : `성공 확률 약 ${Math.round(captureChance(foe) * 100)}% · 체력이 낮을수록↑`}</small>
                </button>
                <button className="cmd back" onClick={() => setMenu('main')}>
                  ← 뒤로
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function InfoCard({ f, hp, side }: { f: Fighter; hp: number; side: 'ally' | 'enemy' }) {
  const ratio = Math.max(0, hp) / f.maxHp;
  return (
    <div className={`info-card ${side}`}>
      <div className="ic-name">
        <span style={{ color: ELEMENT_COLOR[f.element] }}>{ELEMENT_ICON[f.element]}</span> {f.name} <small>Lv.{f.level}</small>
        {f.status && <span className={`st-badge ${f.status}`}>{STATUS_LABEL[f.status]}</span>}
      </div>
      <div className="ic-hp">
        <div style={{ width: `${ratio * 100}%`, background: ratio > 0.5 ? '#58d68d' : ratio > 0.2 ? '#f4d03f' : '#ff6b6b' }} />
      </div>
      {side === 'ally' && (
        <div className="ic-num">
          {Math.max(0, hp)} / {f.maxHp}
        </div>
      )}
    </div>
  );
}

function SwitchList({ d, onPick, onBack, forced, pulse }: { d: Duel; onPick: (uid: string) => void; onBack?: () => void; forced?: boolean; pulse: (k: string) => string }) {
  const foe = activeEnemy(d);
  return (
    <div className="switch-list">
      {forced && <div className="small center">다음에 내보낼 동료를 고르세요</div>}
      {d.allies.map((x) => {
        const best = Math.max(...x.moves.map((s) => estimate(x, foe, MOVES[s.id]).type));
        const isCur = x.uid === activeAlly(d).uid && !forced;
        return (
          <button key={x.uid} className={`sw-btn ${pulse(`ally:${x.defId}`)}`} disabled={x.hp <= 0 || isCur} onClick={() => onPick(x.uid)}>
            <img src={sprite(SPIRITS[x.defId], x.stage)} alt="" />
            <span className="sw-name">
              {ELEMENT_ICON[x.element]} {x.name} Lv.{x.level}
              {isCur && <small> (싸우는 중)</small>}
            </span>
            <span className="sw-hp">
              <span style={{ width: `${(x.hp / x.maxHp) * 100}%` }} />
            </span>
            {x.hp > 0 && best > 1 && <span className="mv-tag adv">유리!</span>}
            {x.hp <= 0 && <span className="mv-tag dis">기절</span>}
          </button>
        );
      })}
      {onBack && (
        <button className="cmd back" onClick={onBack}>
          ← 뒤로
        </button>
      )}
    </div>
  );
}
