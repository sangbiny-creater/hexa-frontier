import { useEffect, useRef, useState } from 'react';
import { elementMultiplier, ELEMENT_LABEL } from '../core/board';
import { HOUR } from '../core/clock';
import type { Duel } from '../core/duel';
import {
  currentObjective,
  enterTile,
  finishDuel,
  idlePreview,
  idleUnlocked,
  mapUnlocked,
  objectiveTile,
  partyIds,
  partyLevel,
  reachableTiles,
  stageProgress,
  summon,
  summonUnlocked,
  travel,
  walkPath,
  type DuelSummary,
  type GameState,
} from '../core/game';
import type { Element } from '../core/types';
import { BALANCE } from '../data/balance';
import { MAP_ORDER, MAPS, TILE_BY_ID } from '../data/map';
import { SPIRITS } from '../data/spirits';
import { asset, ELEMENT_ICON, ElementChart, ElementTag, GOLD, portrait, RoleTag, STONE } from './art';
import { BattlePrep } from './BattlePrep';
import { BattleView } from './BattleView';
import { CampView } from './CampView';
import { MapView } from './MapView';
import { ResultView, type ResultAction } from './ResultView';
import { SpiritView } from './SpiritView';
import { useGame } from './store';
import { SummonView } from './SummonView';
import { battleHint, computeGuide, GuideBar, Intro, lessonDue, type LessonId, type Tab } from './tutorial';

export function App() {
  const { state, now, act, dev, notice, clearNotice } = useGame();
  const [tab, setTab] = useState<Tab>('map');
  const [selected, setSelected] = useState<string | null>(null);
  const [walk, setWalk] = useState<string | null>(null); // 걸어가는 중인 칸
  const [duel, setDuel] = useState<Duel | null>(null);
  const [result, setResult] = useState<{ duel: Duel; sum: DuelSummary } | null>(null);
  const [joined, setJoined] = useState<{ id: string; dup: boolean } | null>(null);
  const [evolveQ, setEvolveQ] = useState<{ id: string; stage: number }[]>([]);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [devOpen, setDevOpen] = useState(false);
  const [help, setHelp] = useState(false);
  const [elemOpen, setElemOpen] = useState(false);
  const [elemFocus, setElemFocus] = useState<Element | null>(null);
  const walkTimer = useRef<number | null>(null);

  const tut = state.tutorial;
  const tutActive = tut.introSeen && !tut.done;
  const busy = !!duel || !!result || !!joined || evolveQ.length > 0;
  const lesson = !busy ? lessonDue(state) : null;
  const guide = busy || lesson || elemOpen || elemFocus || walk ? null : computeGuide(state, { selected, tab, now });
  const objTile = objectiveTile(state);
  const mapTarget = guide ? (guide.target?.kind === 'tile' ? guide.target.id : null) : objTile;
  const markSeen = (id: string) => act((s) => void (s.tutorial.seen.includes(id) || s.tutorial.seen.push(id)));
  const canIdle = idleUnlocked(state);
  const canSummon = summonUnlocked(state);
  const idle = idlePreview(state, now);

  useEffect(() => {
    if (tutActive && tab === 'camp' && state.cleared.includes('b1') && !tut.seen.includes('camp')) markSeen('camp');
  }, [tab, tutActive, state.cleared, tut.seen]); // eslint-disable-line react-hooks/exhaustive-deps

  const toast = (m: string) => {
    setToastMsg(m);
    setTimeout(() => setToastMsg((c) => (c === m ? null : c)), 2400);
  };

  const enter = (id: string) => {
    const r = act((s, t) => enterTile(s, id, t));
    setSelected(null);
    if (r.type === 'duel') setDuel(r.duel);
    else if (r.type === 'resource') {
      const b = r.bonus;
      toast(
        [b.gold && `${GOLD} +${b.gold}`, b.stones && `${STONE} +${b.stones}`, b.summon && `🔮 결정 +${b.summon} (포획 1개·소환 10개)`, b.potion && `💊 회복약 +${b.potion}`].filter(Boolean).join('  '),
      );
    } else if (r.type === 'gate') toast('다음 지역은 준비 중이에요.');
    else if (r.type === 'travel') toast(`${r.map} ${MAPS[r.map].name}에 들어섰어요!`);
    else if (r.type === 'error') toast(r.message);
  };

  /** 칸 누르기: 주인공이 길을 따라 한 칸씩 걸어간 뒤 칸 정보를 연다 */
  const tapTile = (id: string) => {
    if (walk) return;
    if (tutActive && guide) {
      if (guide.target?.kind === 'tile' && id !== guide.target.id) return toast('먼저 ▼ 표시된 칸을 눌러 줘!');
      if (guide.target?.kind === 'tab') return toast('아래 안내를 먼저 따라 줘!');
    }
    const t = TILE_BY_ID[id];
    const cleared = state.cleared.includes(id);
    if (!cleared && !reachableTiles(state).has(id)) return toast('아직 갈 수 없는 칸이에요. 아래쪽 칸부터!');
    const path = walkPath(state, id);
    const steps = cleared ? path.slice(1) : path.slice(1, -1); // 아직 안 간 칸은 바로 앞까지 걷는다
    if (!steps.length) return setSelected(id);
    if (walkTimer.current) clearInterval(walkTimer.current);
    let i = 0;
    setWalk(steps[0]);
    walkTimer.current = window.setInterval(() => {
      i++;
      if (i >= steps.length) {
        clearInterval(walkTimer.current!);
        walkTimer.current = null;
        if (cleared && !t.encounterId) act((s) => void (s.lastTile = id));
        else if (cleared || steps.length) act((s) => void (s.lastTile = steps[steps.length - 1]));
        setWalk(null);
        setSelected(id);
        return;
      }
      setWalk(steps[i]);
    }, 170);
  };

  const goTab = (t: Tab) => {
    if (tutActive && guide?.target?.kind === 'tab' && guide.target.tab !== t) return toast('반짝이는 탭을 눌러 줘!');
    setSelected(null);
    setTab(t);
  };

  const onResult = (a: ResultAction, tileId?: string) => {
    const from = result?.duel.tileId;
    setResult(null);
    if (a === 'farm' && tileId) (setTab('map'), setSelected(tileId));
    else if (a === 'party' && from) (setTab('map'), setSelected(from));
    else if (a === 'shop') setTab('camp');
    else setTab('map');
  };

  const tile = selected ? TILE_BY_ID[selected] : null;
  const party = partyIds(state);

  return (
    <div className="app">
      <header className="hud">
        <img className="hud-face" src={asset('hero-p')} alt="" onClick={() => setHelp(true)} />
        <div className="hud-power">
          <small>파티</small>
          <div className="hud-party">
            {party.map((id) => (
              <img key={id} src={portrait(SPIRITS[id], state.spirits[id].stage)} alt="" />
            ))}
            <b>Lv.{partyLevel(state)}</b>
          </div>
        </div>
        <div className="hud-res">
          <span>
            {GOLD} {state.gold.toLocaleString()}
          </span>
          <span>
            🔮 {state.summonStones} 💊 {state.items.potion}
          </span>
        </div>
        <button className="icon-btn elem-btn" onClick={() => setElemOpen(true)} aria-label="속성표">
          🔥💧
        </button>
        <button className="icon-btn" onClick={() => setDevOpen(!devOpen)} aria-label="설정">
          ⚙
        </button>
      </header>
      {devOpen && (
        <div className="devbar">
          <span>개발 도구</span>
          <button onClick={() => dev.advance(60_000)}>+1분</button>
          <button onClick={() => dev.advance(HOUR)}>+1시간</button>
          <button onClick={() => act((s) => (s.gold += 1000))}>{GOLD}+1000</button>
          <button onClick={() => act((s) => (s.summonStones += 10))}>🔮+10</button>
          <button onClick={() => act((s) => (s.items.potion += 5))}>💊+5</button>
          <button onClick={() => act((s) => (s.stones += 50))}>{STONE}+50</button>
          <button onClick={() => setHelp(true)}>게임 방법</button>
          <button
            className="danger"
            onClick={() => {
              if (confirm('처음부터 다시 시작할까요?')) {
                dev.resetSave();
                setTab('map');
              }
            }}
          >
            새 게임
          </button>
        </div>
      )}
      <button
        className="objective"
        onClick={() => {
          if (objTile) {
            setTab('map');
            tapTile(objTile);
          }
        }}
      >
        <span className="obj-label">목표</span>
        {currentObjective(state)}
      </button>

      <main className="content">
        {tab === 'map' && (
          <>
            <div className="region">
              <b>{state.map}</b> {MAPS[state.map].name}
              {state.map !== 'P00' &&
                (() => {
                  const p = stageProgress(state, state.map);
                  return <span className="region-prog"> {p.cleared}/{p.total}</span>;
                })()}
              {MAP_ORDER.filter((m) => m !== state.map && mapUnlocked(state, m)).map((m) => (
                <button
                  key={m}
                  className="region-go"
                  onClick={() => {
                    if (tutActive) return toast('튜토리얼을 먼저 끝내 줘!');
                    const err = act((s) => travel(s, m));
                    if (err) return toast(err);
                    setSelected(null);
                  }}
                >
                  {m} ▸
                </button>
              ))}
            </div>
            <MapView key={state.map} state={state} now={now} selected={selected} target={mapTarget} heroTile={walk} onTap={tapTile} />
          </>
        )}
        {tab === 'spirit' && <SpiritView state={state} act={act} toast={toast} />}
        {tab === 'summon' && (
          <SummonView
            state={state}
            focus={null}
            onSummon={(mode) => {
              const r = act((s) => summon(s, mode));
              if ('error' in r) return toast(r.error);
              setJoined({ id: r.spiritId, dup: r.duplicate });
            }}
          />
        )}
        {tab === 'camp' && <CampView state={state} now={now} act={act} toast={toast} />}
      </main>

      {guide && <GuideBar guide={guide} onFinish={() => act((s) => (s.tutorial.done = true))} onSkip={() => act((s) => (s.tutorial.done = true))} />}

      <nav className="tabbar">
        {(
          [
            ['map', '🗺', '탐험'],
            ['spirit', '🐾', '스피릿'],
            ['summon', canSummon ? '✨' : '🔒', '소환'],
            ['camp', '🏕', '캠프'],
          ] as [Tab, string, string][]
        ).map(([k, icon, label]) => (
          <button key={k} className={`${tab === k ? 'on' : ''} ${guide?.target?.kind === 'tab' && guide.target.tab === k ? 'pulse' : ''} ${k === 'summon' && !canSummon ? 'locked' : ''}`} onClick={() => goTab(k)}>
            <span>{icon}</span>
            {label}
            {k === 'summon' && canSummon && state.summonStones >= BALANCE.summon.cost && <i className="badge">!</i>}
            {k === 'camp' && canIdle && idle.gold > 0 && <i className="badge">!</i>}
          </button>
        ))}
      </nav>

      {tile && tab === 'map' && tile.encounterId && !busy && (
        <BattlePrep
          state={state}
          tileId={tile.id}
          now={now}
          guideText={guide && (guide.target?.kind === 'tileAction' || guide.target?.kind === 'suggest') ? guide.text : null}
          focus={guide?.target?.kind === 'tileAction'}
          focusSuggest={guide?.target?.kind === 'suggest'}
          act={act}
          toast={toast}
          onGo={() => enter(tile.id)}
          onClose={() => setSelected(null)}
          onElement={(el) => setElemFocus(el)}
        />
      )}
      {tile && tab === 'map' && !tile.encounterId && !busy && (
        <TileSheet state={state} id={tile.id} focus={guide?.target?.kind === 'tileAction'} onGo={() => enter(tile.id)} onClose={() => setSelected(null)} />
      )}

      {duel && (
        <BattleView
          duel={duel}
          instant={state.settings.skipBattle && !(tutActive && state.map === 'P00')}
          hint={(d, menu) => battleHint(state, d, menu)}
          onFinish={(d) => {
            const sum = act((s, t) => finishDuel(s, d, t));
            setDuel(null);
            setResult({ duel: d, sum });
            if (sum.evolved.length) setEvolveQ(sum.evolved);
          }}
        />
      )}
      {result && !duel && evolveQ.length === 0 && (
        <ResultView
          state={state}
          duel={result.duel}
          sum={result.sum}
          now={now}
          tip={tutActive && !result.sum.won && result.sum.result === 'lose' ? '괜찮아! 진 이유를 생각해 보자. 아래 버튼을 누르면 바로 해결하러 가.' : null}
          onAction={onResult}
        />
      )}

      {joined && (
        <div className="modal" onClick={() => setJoined(null)}>
          <div className="reveal">
            <div className="reveal-tag">{joined.dup ? '✨ 같은 동료! 경험치로' : '✨ 소환 성공!'}</div>
            <img className="reveal-art" src={portrait(SPIRITS[joined.id], state.spirits[joined.id]?.stage ?? 1)} alt="" />
            <h2>{SPIRITS[joined.id].stages?.[(state.spirits[joined.id]?.stage ?? 1) - 1]}</h2>
            <div className="muted">{SPIRITS[joined.id].title}</div>
            <div className="tags">
              <ElementTag element={SPIRITS[joined.id].element} /> <RoleTag role={SPIRITS[joined.id].role} />
            </div>
            <div className="reveal-power">Lv.{state.spirits[joined.id]?.level}</div>
            {!joined.dup && state.formation[joined.id] === undefined && <div className="small">파티가 꽉 찼어요. 🐾스피릿 탭이나 전투 준비 화면에서 넣을 수 있어요.</div>}
            <button className="cta">좋아!</button>
          </div>
        </div>
      )}

      {evolveQ.length > 0 && (
        <div className="modal" onClick={() => setEvolveQ((q) => q.slice(1))}>
          <div className="reveal evo">
            <div className="reveal-tag">✨ 빛이 감싼다 — 진화!</div>
            <div className="evo-row">
              <img src={portrait(SPIRITS[evolveQ[0].id], evolveQ[0].stage - 1)} alt="" />
              <span>➜</span>
              <img className="reveal-art" src={portrait(SPIRITS[evolveQ[0].id], evolveQ[0].stage)} alt="" />
            </div>
            <h2>{SPIRITS[evolveQ[0].id].stages?.[evolveQ[0].stage - 1]}(으)로 진화!</h2>
            <div className="muted">능력치가 크게 올랐어요!</div>
            <button className="cta">멋져!</button>
          </div>
        </div>
      )}

      {lesson && <Lesson id={lesson} state={state} onClose={() => markSeen(lesson)} />}

      {(elemOpen || elemFocus) && (
        <div className="modal" onClick={() => (setElemOpen(false), setElemFocus(null))}>
          <div className="reveal elem-modal" onClick={(e) => e.stopPropagation()}>
            <div className="reveal-tag">속성 상성</div>
            <ElementChart focus={elemFocus ?? undefined} />
            {elemFocus && <FocusLines el={elemFocus} />}
            <p className="elem-rule">
              <b>화살표 방향으로 강해요.</b> 강한 상대에게 기술 피해 <b className="adv">×2</b>, 약한 상대에게는 <b className="dis">×½</b>. 내 속성과 같은 기술은 ×1.5!
            </p>
            <div className="elem-lines">💧물 → 🔥불 → 🌿숲 → ⛰️대지 → 🌪️바람 → 💧물</div>
            <button className="cta" onClick={() => (setElemOpen(false), setElemFocus(null))}>
              알겠어!
            </button>
          </div>
        </div>
      )}

      {!tut.introSeen && (
        <Intro
          hasProgress={state.cleared.length > 1}
          onStart={() => {
            dev.resetSave((s) => (s.tutorial.introSeen = true));
            setTab('map');
            setSelected(null);
          }}
          onContinue={() => act((s) => ((s.tutorial.introSeen = true), (s.tutorial.done = true)))}
        />
      )}
      {help && <Intro hasProgress={false} onStart={() => {}} onClose={() => setHelp(false)} />}

      {notice && (
        <div className="notice" onClick={clearNotice}>
          ⚠ {notice}
        </div>
      )}
      {toastMsg && <div className="toast">{toastMsg}</div>}
    </div>
  );
}

/** 튜토리얼 설명 팝업 */
function Lesson({ id, state, onClose }: { id: LessonId; state: GameState; onClose: () => void }) {
  const content: Record<LessonId, { tag: string; body: React.ReactNode; cta: string }> = {
    type: {
      tag: '속성 상성',
      body: (
        <>
          <ElementChart highlight={['fire', 'forest']} />
          <p className="elem-rule big-rule">
            방금 <b>"상성 적중! ×2"</b> 봤지? 🔥불 기술은 🌿숲에게 <b className="adv">×2</b>!
          </p>
          <div className="lesson-list">
            <div>✔ 화살표 방향으로 강해요: 💧물 → 🔥불 → 🌿숲 → ⛰️대지 → 🌪️바람 → 💧물</div>
            <div>✔ 반대 방향이면 <b className="dis">×½</b> "상성 ×½"</div>
            <div>✔ 기술 버튼에 "상성 ×2" 표시가 떠요</div>
            <div>✔ 내 속성과 같은 기술은 위력 ×1.5</div>
          </div>
        </>
      ),
      cta: '알겠어!',
    },
    capture: {
      tag: '새 동료!',
      body: (
        <>
          <div className="match-table">
            {Object.keys(state.spirits).map((sid) => (
              <div key={sid}>
                <img src={portrait(SPIRITS[sid], state.spirits[sid].stage)} alt="" />
                <span>
                  {ELEMENT_ICON[SPIRITS[sid].element]} Lv.{state.spirits[sid].level}
                </span>
              </div>
            ))}
          </div>
          <div className="lesson-list">
            <div>✔ 파티는 {state.maxDeploy}명까지. <b>1번(선두)</b>이 먼저 나가요</div>
            <div>✔ 전투 중 <b>🔄교체</b>로 바꿀 수 있어요 (한 턴 사용)</div>
            <div>✔ 경험치는 <b>싸운 동료만</b> 받아요</div>
            <div>✔ 야생 몬스터는 체력을 줄일수록 잘 잡혀요. 보스는 못 잡아요</div>
          </div>
        </>
      ),
      cta: '좋아!',
    },
    boss: {
      tag: '보스 전투',
      body: (
        <div className="lesson-list">
          <div>👑 보스는 체력이 많고, <b>잡을 수도 도망칠 수도 없어요</b></div>
          <div>🌿 고목 골렘은 숲 속성 → 🔥불 기술이 ×2</div>
          <div>🎒 위험하면 💊회복약 (한 턴 사용)</div>
          <div>⭐ 지면 이긴 칸에서 경험치를 벌어 레벨을 올리면 돼요</div>
          <div>✨ 결정 10개로 ✨소환 탭에서 원하는 속성 동료를 부를 수도 있어요</div>
        </div>
      ),
      cta: '도전!',
    },
    magic: {
      tag: '물리 ⚔️ / 마법 ✨',
      body: (
        <>
          <div className="lesson-list">
            <div>⚔️ <b>물리 기술</b>은 상대의 <b>방어</b>로 막혀요</div>
            <div>✨ <b>마법 기술</b>은 상대의 <b>마법방어</b>로 막혀요</div>
            <div>◇ 변화 기술은 능력치를 올리거나 상태이상을 걸어요</div>
          </div>
          <p className="elem-rule big-rule">
            다음 <b>물안개 여울</b>의 여우는 물안개로 ✨마법을 막아요. 기술 버튼에 "막힘"이 뜨면 ⚔️물리 기술로!
          </p>
          <p className="muted small">들이받기·날쌘 발걸음·불꽃 할퀴기·자갈 날리기·찌릿 박치기 같은 기술이 물리예요.</p>
        </>
      ),
      cta: '알겠어!',
    },
    evolve: {
      tag: '진화!',
      body: (
        <div className="lesson-list">
          <div>✨ 동료는 <b>Lv.{BALANCE.evolution.levelCap[0]}</b>과 <b>Lv.{BALANCE.evolution.levelCap[1]}</b>에 진화해요</div>
          <div>💪 진화하면 모습이 바뀌고 능력치가 크게 올라요</div>
          <div>📖 레벨이 오르면 새 기술도 배워요 (🐾스피릿에서 4개 고르기)</div>
        </div>
      ),
      cta: '멋져!',
    },
  };
  const c = content[id];
  return (
    <div className="modal">
      <div className="reveal elem-modal">
        <div className="reveal-tag">{c.tag}</div>
        {c.body}
        <button className="cta" onClick={onClose}>
          {c.cta}
        </button>
      </div>
    </div>
  );
}

const ELEMENTS: Element[] = ['water', 'fire', 'forest', 'earth', 'electric'];

function FocusLines({ el }: { el: Element }) {
  const strongVs = ELEMENTS.filter((e) => elementMultiplier(e, el) > 1);
  const weakVs = ELEMENTS.filter((e) => elementMultiplier(e, el) < 1);
  const name = (e: Element) => `${ELEMENT_ICON[e]}${ELEMENT_LABEL[e]}`;
  return (
    <div className="focus-lines">
      <div>
        {name(el)} 적에게 <b className="adv">상성 ×2</b>: <b>{strongVs.map(name).join(' ')}</b> 기술 (×2)
      </div>
      <div>
        {name(el)} 적에게 <b className="dis">상성 ×½</b>: <b>{weakVs.map(name).join(' ')}</b> 기술 (×½)
      </div>
    </div>
  );
}

function TileSheet({ state, id, focus, onGo, onClose }: { state: GameState; id: string; focus: boolean; onGo: () => void; onClose: () => void }) {
  const t = TILE_BY_ID[id];
  const cleared = state.cleared.includes(id);
  const canGo = reachableTiles(state).has(id) || (t.kind === 'gate' && cleared);
  const label = t.kind === 'resource' ? '줍기' : t.kind === 'gate' ? '다음 지역으로' : '확인';
  const what = t.resource === 'summon' ? `🔮 결정 ${t.amount ?? ''}개 — 봉인 결정(1개)·소환(10개)에 써요` : t.resource === 'potion' ? `💊 회복약 ${t.amount ?? ''}개 — 전투 중 체력 50% 회복` : t.resource === 'stones' ? `${STONE} 성장석 — 승급에 써요` : `${GOLD} 골드 — 상점·승급에 써요`;

  return (
    <div className="sheet-wrap" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />
        <div className="sheet-head">
          <b>{t.name}</b>
          <button className="icon-btn" onClick={onClose}>
            ✕
          </button>
        </div>
        {t.kind === 'resource' && !cleared && (
          <div className="spirit-preview">
            <img src={asset(t.resource === 'summon' ? 'tile-crystal' : 'tile-treasure')} alt="" />
            <div className="small">{what}</div>
          </div>
        )}
        {t.kind === 'start' && <div className="muted">{t.hint}</div>}
        {t.kind === 'gate' && (
          <div className="muted">
            {t.map === 'P00' ? (mapUnlocked(state, 'P01') ? '튜토리얼 끝! 본편 P01(스테이지 100개)로 출발해요.' : '바위엄니 대장을 물리치면 열려요.') : '다음 지역은 준비 중이에요.'}
          </div>
        )}
        {canGo && t.kind !== 'start' ? (
          <button className={`cta ${focus ? 'pulse' : ''}`} onClick={onGo}>
            {label}
          </button>
        ) : (
          t.kind !== 'start' && <div className="muted small center">{cleared ? '이미 연 칸이에요' : '아래쪽 칸을 먼저 이겨야 갈 수 있어요'}</div>
        )}
      </div>
    </div>
  );
}


