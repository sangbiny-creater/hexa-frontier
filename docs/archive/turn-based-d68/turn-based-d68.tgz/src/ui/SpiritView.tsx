// 스피릿 탭 (D68): 파티(전투 순서) + 보유 동료 카드 + 상세(능력치·기술 4개 고르기·진화·승급).
import { useEffect, useRef, useState } from 'react';
import { ELEMENT_LABEL } from '../core/board';
import { fighterStats } from '../core/duel';
import { ALL_SUMMONABLE, canRankUp, makeLead, partyIds, rankUp, setMoves, spiritMoves, toggleParty, type GameState } from '../core/game';
import { rankUpCost, xpToNext } from '../core/growth';
import { elementMultiplier } from '../core/board';
import type { Element } from '../core/types';
import { BALANCE } from '../data/balance';
import { LEARNSETS, learnedMoves, MOVES } from '../data/moves';
import { SPIRITS } from '../data/spirits';
import { Bar, ELEMENT_COLOR, ELEMENT_ICON, ElementTag, GOLD, portrait, RoleTag, stageName, STONE } from './art';

type Act = <T>(fn: (s: GameState, now: number) => T) => T;
const ELEMENTS: Element[] = ['water', 'fire', 'forest', 'earth', 'electric'];
const CAT = { phys: '⚔️물리', magic: '✨마법', status: '◇변화' } as const;
const EVO_AT = BALANCE.evolution.levelCap;

export function SpiritView({ state, act, toast, focusSpirit }: { state: GameState; act: Act; toast: (m: string) => void; focusSpirit?: string | null }) {
  const [detail, setDetail] = useState<string | null>(focusSpirit ?? null);
  useEffect(() => {
    if (focusSpirit) setDetail(focusSpirit);
  }, [focusSpirit]);
  const party = partyIds(state);
  const owned = Object.keys(state.spirits).sort((a, b) => (party.includes(a) ? party.indexOf(a) : 99) - (party.includes(b) ? party.indexOf(b) : 99) || state.spirits[b].level - state.spirits[a].level);
  const notOwned = ALL_SUMMONABLE.filter((id) => !state.spirits[id]);

  return (
    <div className="page">
      <h3 className="sec">
        파티 <span className="muted small">{party.length}/{state.maxDeploy}명 · 1번이 전투에 먼저 나가요</span>
      </h3>
      <div className="party-row">
        {Array.from({ length: state.maxDeploy }, (_, i) => {
          const id = party[i];
          const sp = id ? state.spirits[id] : null;
          return (
            <button key={i} className={`party-slot ${id ? '' : 'empty'}`} onClick={() => id && setDetail(id)}>
              <span className="pm-no">{i + 1}</span>
              {id && sp ? (
                <>
                  <img src={portrait(SPIRITS[id], sp.stage)} alt="" />
                  <small>
                    {ELEMENT_ICON[SPIRITS[id].element]} Lv.{sp.level}
                  </small>
                </>
              ) : (
                <small className="muted">비어 있음</small>
              )}
            </button>
          );
        })}
      </div>

      <h3 className="sec">
        보유 동료 <span className="muted small">{owned.length}명 · 누르면 상세</span>
      </h3>
      <div className="card-grid">
        {owned.map((id) => {
          const sp = state.spirits[id];
          const d = SPIRITS[id];
          return (
            <button key={id} className={`spcard ${party.includes(id) ? 'in-party' : ''}`} style={{ borderColor: ELEMENT_COLOR[d.element] }} onClick={() => setDetail(id)}>
              {party.includes(id) && <span className="pm-no small-no">{party.indexOf(id) + 1}</span>}
              <img src={portrait(d, sp.stage)} alt="" />
              <div className="spcard-name">{stageName(d, sp.stage)}</div>
              <div className="spcard-sub">
                {ELEMENT_ICON[d.element]} Lv.{sp.level}
              </div>
              <Bar value={sp.xp} max={xpToNext(sp.level)} color="#7ab8ff" h={4} />
            </button>
          );
        })}
        {notOwned.map((id) => (
          <div key={id} className="spcard locked">
            <img src={portrait(SPIRITS[id], 1)} alt="" />
            <div className="spcard-name">🔒 {SPIRITS[id].stages?.[0]}</div>
            <div className="spcard-sub">야생에서 잡거나 소환</div>
          </div>
        ))}
      </div>
      <p className="explain small">
        레벨은 <b>전투 경험치</b>로 올라요(싸운 동료만). 레벨이 오르면 <b>새 기술</b>을 배우고, Lv.{EVO_AT[0]}·Lv.{EVO_AT[1]}에 <b>진화</b>해요. 야생 몬스터는 🔮봉인 결정로 잡을 수 있어요.
      </p>

      {detail && state.spirits[detail] && (
        <SpiritDetail
          state={state}
          ids={owned}
          id={detail}
          act={act}
          toast={toast}
          onChange={setDetail}
          onClose={() => setDetail(null)}
          onToggle={(id) => {
            const err = act((s) => toggleParty(s, id));
            if (err) toast(err);
          }}
          onLead={(id) => act((s) => makeLead(s, id))}
          onRank={(id) => {
            const err = act((s) => rankUp(s, id));
            toast(err ?? '승급! 능력치 +12%');
          }}
        />
      )}
    </div>
  );
}

function SpiritDetail({
  state,
  ids,
  id,
  act,
  toast,
  onChange,
  onClose,
  onToggle,
  onLead,
  onRank,
}: {
  state: GameState;
  ids: string[];
  id: string;
  act: Act;
  toast: (m: string) => void;
  onChange: (id: string) => void;
  onClose: () => void;
  onToggle: (id: string) => void;
  onLead: (id: string) => void;
  onRank: (id: string) => void;
}) {
  const touch = useRef<number | null>(null);
  const idx = ids.indexOf(id);
  const go = (d: number) => onChange(ids[(idx + d + ids.length) % ids.length]);
  const def = SPIRITS[id];
  const sp = state.spirits[id];
  const st = fighterStats(def, 'ally', sp.level, sp.rank, sp.stage);
  const moves = spiritMoves(state, id);
  const learned = learnedMoves(id, sp.level);
  const upcoming = (LEARNSETS[id] ?? []).filter(([lv]) => lv > sp.level);
  const strong = ELEMENTS.filter((e) => elementMultiplier(def.element, e) > 1);
  const weak = ELEMENTS.filter((e) => elementMultiplier(e, def.element) > 1);
  const party = partyIds(state);
  const inParty = party.includes(id);
  const rc = rankUpCost(sp);

  const toggleMove = (m: string) => {
    const next = moves.includes(m) ? moves.filter((x) => x !== m) : moves.length >= 4 ? null : [...moves, m];
    if (!next) return toast('기술은 4개까지! 먼저 쓰던 기술 하나를 빼세요');
    const err = act((s) => setMoves(s, id, next));
    if (err) toast(err);
  };

  return (
    <div
      className="screen detail"
      onTouchStart={(e) => (touch.current = e.touches[0].clientX)}
      onTouchEnd={(e) => {
        if (touch.current === null) return;
        const dx = e.changedTouches[0].clientX - touch.current;
        touch.current = null;
        if (Math.abs(dx) > 60) go(dx < 0 ? 1 : -1);
      }}
    >
      <div className="detail-top">
        <button className="icon-btn" onClick={onClose}>
          ✕
        </button>
        <span className="muted small">
          {idx + 1} / {ids.length} · 옆으로 밀어서 넘기기
        </span>
        <span style={{ width: 34 }} />
      </div>
      <div className="detail-scroll">
        <div className="detail-hero" style={{ background: `radial-gradient(circle at 50% 40%, ${ELEMENT_COLOR[def.element]}55, transparent 70%)` }}>
          <button className="nav-btn" onClick={() => go(-1)}>
            ‹
          </button>
          <img src={portrait(def, sp.stage)} alt="" />
          <button className="nav-btn" onClick={() => go(1)}>
            ›
          </button>
        </div>
        <div className="detail-name">
          <h2>{stageName(def, sp.stage)}</h2>
          <div className="muted">
            {def.name} · {def.title}
          </div>
          <div className="tags">
            <ElementTag element={def.element} /> <RoleTag role={def.role} />
            <span className="tag">{inParty ? `파티 ${party.indexOf(id) + 1}번` : '대기'}</span>
          </div>
          <div className="detail-power">
            Lv.{sp.level} {'★'.repeat(sp.rank)}
          </div>
          <Bar value={sp.xp} max={xpToNext(sp.level)} color="#7ab8ff" h={6} />
          <div className="muted small">
            경험치 {sp.xp} / {xpToNext(sp.level)}
          </div>
          <div className="detail-actions">
            <button className="ghost small-btn" onClick={() => onToggle(id)}>
              {inParty ? '파티에서 빼기' : '파티에 넣기'}
            </button>
            {party[0] !== id && (
              <button className="ghost small-btn" onClick={() => onLead(id)}>
                선두로 (1번)
              </button>
            )}
          </div>
        </div>

        <div className="dbox">
          <h4>기술 (전투에서 고르는 4개)</h4>
          <div className="move-list">
            {learned.map((m) => {
              const mv = MOVES[m];
              const on = moves.includes(m);
              return (
                <button key={m} className={`move-row ${on ? 'on' : ''}`} onClick={() => toggleMove(m)} style={{ borderColor: mv.element ? ELEMENT_COLOR[mv.element] : '#888' }}>
                  <b>
                    {on ? '✔ ' : ''}
                    {mv.name}
                  </b>
                  <span className="small">
                    {mv.element ? `${ELEMENT_ICON[mv.element]}${ELEMENT_LABEL[mv.element]}` : '무속성'} · {CAT[mv.cat]}
                    {mv.power ? ` · 위력 ${mv.power}` : ''} · PP {mv.pp}
                  </span>
                  <span className="small muted">{mv.desc}</span>
                </button>
              );
            })}
            {upcoming.map(([lv, m]) => (
              <div key={m} className="move-row locked">
                <b>🔒 Lv.{lv}</b>
                <span className="small muted">
                  {MOVES[m].name} ({MOVES[m].element ? ELEMENT_ICON[MOVES[m].element!] : '무속성'} {CAT[MOVES[m].cat]})
                </span>
              </div>
            ))}
          </div>
          <div className="small muted">기술을 누르면 넣고 뺄 수 있어요. 같은 속성 기술은 위력 ×1.5!</div>
        </div>

        <div className="dbox">
          <h4>능력치</h4>
          <div className="stats">
            <div>
              <small>체력</small>
              <b>{st.maxHp}</b>
            </div>
            <div>
              <small>공격</small>
              <b>{Math.round(st.atk)}</b>
            </div>
            <div>
              <small>방어</small>
              <b>{Math.round(st.def)}</b>
            </div>
            <div>
              <small>마법방어</small>
              <b>{Math.round(st.res)}</b>
            </div>
            <div>
              <small>속도</small>
              <b>{Math.round(st.spd)}</b>
            </div>
          </div>
          <div className="small muted">⚔️물리 기술은 상대의 방어, ✨마법 기술은 마법방어로 막혀요. 속도가 빠르면 먼저 공격해요.</div>
        </div>

        <div className="dbox">
          <h4>속성 상성</h4>
          <div className="small">
            강한 상대: {strong.map((e) => `${ELEMENT_ICON[e]}${ELEMENT_LABEL[e]}`).join(' ')} <b className="adv">(기술 피해 ×2)</b>
          </div>
          <div className="small">
            약한 상대: {weak.map((e) => `${ELEMENT_ICON[e]}${ELEMENT_LABEL[e]}`).join(' ')} <b className="dis">(받는 피해 ×2)</b>
          </div>
        </div>

        <div className="dbox">
          <h4>진화 (레벨로 자동)</h4>
          <div className="evo-strip">
            {[1, 2, 3].map((s) => (
              <div key={s} className={`evo-cell ${s <= sp.stage ? 'got' : ''}`}>
                <img src={portrait(def, s)} alt="" />
                <small>{def.stages?.[s - 1]}</small>
                <small className="muted">{s === 1 ? '처음' : `Lv.${EVO_AT[s - 2]}`}</small>
              </div>
            ))}
          </div>
          <div className="small">{sp.stage < 3 ? `Lv.${EVO_AT[sp.stage - 1]}이 되면 진화해요! 모습이 바뀌고 능력치 ×${((BALANCE.evolution.statMul as readonly number[])[sp.stage] / BALANCE.evolution.statMul[sp.stage - 1]).toFixed(2)}.` : '최종 진화 완료!'}</div>
        </div>

        <div className="dbox">
          <h4>강화</h4>
          {rc && (
            <button className={`rank-btn ${canRankUp(state, id) ? 'can' : ''}`} disabled={!canRankUp(state, id)} onClick={() => onRank(id)}>
              ★ 승급 {STONE}
              {rc.stones} {GOLD}
              {rc.gold} <small>(Lv.{rc.minLevel}+, 능력치 +12%)</small>
            </button>
          )}
          <div className="locked-row">🔒 장비 — 준비 중</div>
        </div>
      </div>
    </div>
  );
}
