// 밸런스 봇: 자동 전투(가장 좋은 기술)로 P00 → P01을 진행한다. 지면 이긴 칸에서 경험치를 벌고 다시 도전.
// 포획 가능한 적은 체력이 절반 아래면 구슬을 던진다. 실행: npx tsx sim/duel-run.ts [P01까지=1]
import { autoDuel } from '../src/core/duel';
import { bestFarmTile, buy, claimIdle, enterTile, finishDuel, newGame, objectiveTile, partyIds, partyLevel, reachableTiles, setParty, travel, type GameState } from '../src/core/game';
import { HOUR } from '../src/core/clock';
import { suggestTeam } from '../src/core/power';
import { TILE_BY_ID } from '../src/data/map';

export function runBot(seed: number, opts: { toStage?: number; log?: boolean } = {}) {
  const s: GameState = newGame(1_700_000_000_000 + seed * 977_131);
  s.tutorial.introSeen = true;
  let now = s.createdAt;
  let battles = 0;
  let losses = 0;
  let farm = 0;
  let pendingFarm = 0;
  const log: string[] = [];
  const at: Record<string, string> = {};
  for (let g = 0; g < 4000; g++) {
    if (s.map === 'P00' && s.cleared.includes('b2')) {
      travel(s, 'P01');
      if (!opts.toStage) break;
    }
    if (opts.toStage && s.cleared.includes(`p01-${String(opts.toStage).padStart(3, '0')}`)) break;
    while (s.items.potion < 3 && s.gold > 200) buy(s, 'potion');
    if (s.summonStones < 3 && s.gold > 400) buy(s, 'orb');
    let target = objectiveTile(s);
    if (!target) break;
    // 지고 나면 이긴 칸에서 2번 경험치를 벌고 다시 도전
    if (pendingFarm > 0) {
      const f = bestFarmTile(s, now);
      if (f) {
        target = f;
        pendingFarm--;
        farm++;
      } else {
        now += 60_000;
        claimIdle(s, now);
        continue;
      }
    } else if (!TILE_BY_ID[target].encounterId && !reachableTiles(s).has(target)) break;
    const tt = TILE_BY_ID[target];
    if (tt.encounterId) setParty(s, suggestTeam(Object.keys(s.spirits), tt.encounterId, s.maxDeploy, (id) => s.spirits[id].level));
    const r = enterTile(s, target, now);
    if (r.type === 'error') {
      now += 60_000;
      continue;
    }
    if (r.type !== 'duel') continue;
    const d = autoDuel(r.duel, { capture: true, owned: Object.keys(s.spirits) });
    const sum = finishDuel(s, d, now);
    battles++;
    now += (d.turn * 6 + 10) * 1000;
    if (!sum.won) {
      losses++;
      pendingFarm = 2;
    }
    if (sum.won && (tt.kind === 'boss' || tt.kind === 'elite' || tt.id === 'b2') && !at[tt.stage ? `P01-${tt.stage}` : tt.id])
      at[tt.stage ? `P01-${tt.stage}` : tt.id] = `${battles}전 Lv${partyLevel(s)} ${Math.round((now - s.createdAt) / 60000)}분`;
    if (opts.log)
      log.push(`${tt.id} ${sum.won ? '승' : '패'} t${d.turn} ${partyIds(s).map((id) => id.slice(0, 4) + s.spirits[id].level).join(',')} 포획${sum.captured.map((c) => c.id).join('')} G${s.gold} 🔮${s.summonStones} 💊${s.items.potion}`);
    if (now - s.createdAt > 200 * HOUR) break;
  }
  return { at, battles, losses, farm, owned: Object.keys(s.spirits).map((id) => id + s.spirits[id].level).join(' '), log, s };
}

if (process.argv[1]?.endsWith('duel-run.ts')) {
  const to = Number(process.argv[2] ?? 0);
  const r = runBot(1, { toStage: to || undefined, log: true });
  console.log(r.log.slice(0, 80).join('\n'));
  console.log(r.at, '전투', r.battles, '패배', r.losses, '파밍', r.farm, r.owned);
}
