// 튜토리얼 자동 플레이: 아렌의 지도 안내(computeGuide)를 그대로 따르고, 전투는 전투 안내(battleHint)가
// 가리키는 버튼을 누른다(안내가 없으면 가장 좋은 기술). 테스트·밸런스 확인용.
import { activeAlly, autoCommand, bestSwitch, doTurn, forceSwitch, type Command, type Duel } from '../src/core/duel';
import { claimIdle, enterTile, finishDuel, newGame, setParty, buy } from '../src/core/game';
import { suggestTeam } from '../src/core/power';
import { TILE_BY_ID } from '../src/data/map';
import { battleHint, computeGuide, lessonDue, type Tab } from '../src/ui/tutorial';

function playDuel(s: ReturnType<typeof newGame>, d: Duel) {
  let menu: 'main' | 'moves' | 'switch' | 'bag' = 'main';
  for (let g = 0; g < 600 && !d.over; g++) {
    if (d.needSwitch) {
      forceSwitch(d, bestSwitch(d)!);
      continue;
    }
    const h = battleHint(s, d, menu);
    const f = h?.focus;
    let cmd: Command | null = null;
    if (f === 'fight') menu = 'moves';
    else if (f === 'bag') menu = 'bag';
    else if (f === 'switch') menu = 'switch';
    else if (f?.startsWith('move:')) cmd = { kind: 'move', index: activeAlly(d).moves.findIndex((m) => m.id === f.slice(5)) };
    else if (f?.startsWith('ally:')) cmd = { kind: 'switch', uid: `a:${f.slice(5)}` };
    else if (f === 'orb') cmd = { kind: 'orb' };
    else if (f === 'potion') cmd = { kind: 'potion' };
    else cmd = autoCommand(d);
    if (cmd) {
      doTurn(d, cmd);
      menu = 'main';
    }
  }
  return d;
}

export function runTutorial(seed: number) {
  const s = newGame(1_700_000_000_000 + seed * 977_131);
  s.tutorial.introSeen = true;
  let now = s.createdAt;
  let tab: Tab = 'map';
  let selected: string | null = null;
  const stat = { battles: 0, losses: 0, waits: 0, lossAt: [] as string[], captured: [] as string[] };
  for (let step = 0; step < 3000; step++) {
    const lesson = lessonDue(s);
    if (lesson) {
      s.tutorial.seen.push(lesson);
      continue;
    }
    const g = computeGuide(s, { selected, tab, now });
    if (!g) break;
    if (g.finish) {
      s.tutorial.done = true;
      break;
    }
    const t = g.target;
    if (!t) {
      if (tab === 'camp') buy(s, 'orb');
      now += 30_000;
      stat.waits++;
      continue;
    }
    if (t.kind === 'tab') {
      tab = t.tab;
      selected = null;
      if (tab === 'camp') {
        claimIdle(s, now);
        if (!s.tutorial.seen.includes('camp') && s.cleared.includes('b1')) s.tutorial.seen.push('camp');
      }
    } else if (t.kind === 'tile') selected = t.id;
    else if (t.kind === 'suggest') setParty(s, suggestTeam(Object.keys(s.spirits), TILE_BY_ID[selected!].encounterId!, s.maxDeploy, (id) => s.spirits[id].level));
    else if (t.kind === 'tileAction') {
      const id = selected!;
      selected = null;
      const r = enterTile(s, id, now);
      if (r.type === 'error') throw new Error(`${id}: ${r.message}`);
      if (r.type === 'duel') {
        const d = playDuel(s, r.duel);
        const sum = finishDuel(s, d, now);
        stat.battles++;
        stat.captured.push(...sum.captured.filter((c) => c.isNew).map((c) => c.id));
        if (!sum.won) (stat.losses++, stat.lossAt.push(id));
        now += (d.turn * 7 + 15) * 1000;
      } else now += 3000;
    }
  }
  return { state: s, done: s.tutorial.done, minutes: Math.round((now - s.createdAt) / 60_000), ...stat };
}

if (process.argv[1]?.endsWith('tutorial-bot.ts')) {
  for (let i = 0; i < Number(process.argv[2] ?? 5); i++) {
    const r = runTutorial(i);
    console.log(i, { done: r.done, 분: r.minutes, 전투: r.battles, 패배: r.lossAt.join(' '), 포획: r.captured.join(' '), 대기: r.waits, 파티: Object.entries(r.state.spirits).map(([k, v]) => k + v.level).join(' ') });
  }
}
