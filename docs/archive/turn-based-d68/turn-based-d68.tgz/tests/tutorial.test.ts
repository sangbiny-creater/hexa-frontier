import { describe, expect, it } from 'vitest';
import { newGame, reachableTiles, TUTORIAL_PATH } from '../src/core/game';
import { MAPS } from '../src/data/map';
import { computeGuide } from '../src/ui/tutorial';
import { runTutorial } from '../sim/tutorial-bot';
import { runBot } from '../sim/duel-run';

const T0 = 1_700_000_000_000;

describe('튜토리얼 (D68)', () => {
  it('P00은 한 줄 길이고, 골렘까지 바위가 없다', () => {
    const g = newGame(T0);
    for (const id of TUTORIAL_PATH) {
      expect([...reachableTiles(g)]).toEqual([id]);
      g.cleared.push(id);
    }
    expect(MAPS.P00.noRockUntilRow).toBe(MAPS.P00.tiles.find((t) => t.id === 'b1')!.row);
  });
  it('첫 안내는 첫 칸을 가리킨다', () => {
    const g = newGame(T0);
    g.tutorial.introSeen = true;
    expect(computeGuide(g, { selected: null, tab: 'map' })!.target).toEqual({ kind: 'tile', id: 'a1' });
    expect(computeGuide(g, { selected: 'a1', tab: 'map' })!.target).toEqual({ kind: 'tileAction' });
  });
  it('안내만 따라가면 끝까지 간다: 여우를 잡고, 교체·회복약·물리/마법을 쓰며 보스 둘을 이긴다', () => {
    for (let seed = 0; seed < 8; seed++) {
      const r = runTutorial(seed);
      expect(r.done).toBe(true);
      expect(r.captured).toContain('tidekit');
      expect(r.state.cleared).toContain('b2');
      expect(r.battles).toBeLessThan(45);
    }
  });
});

describe('본편 밸런스', () => {
  it('봇이 자동 전투로 P01-025(첫 중간 보스)까지 간다', () => {
    const r = runBot(1, { toStage: 25 });
    expect(r.s.cleared).toContain('p01-025');
    expect(r.battles).toBeLessThan(120);
  });
});
