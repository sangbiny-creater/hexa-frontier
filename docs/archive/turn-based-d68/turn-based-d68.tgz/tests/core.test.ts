import { describe, expect, it } from 'vitest';
import { elementMultiplier } from '../src/core/board';
import { activeAlly, activeEnemy, autoDuel, captureChance, createDuel, doTurn, enemyFighter, estimate, forceSwitch, type Duel } from '../src/core/duel';
import {
  addSpirit,
  buy,
  enterTile,
  finishDuel,
  giveXp,
  makeLead,
  neighborsOf,
  newGame,
  partyIds,
  reachableTiles,
  respawnMs,
  SAVE_VERSION,
  setMoves,
  stageForLevel,
  summon,
  toggleParty,
  travel,
  walkPath,
} from '../src/core/game';
import { deserialize, serialize } from '../src/core/save';
import { xpToNext } from '../src/core/growth';
import { BALANCE } from '../src/data/balance';
import { MAPS, TILE_BY_ID, TILES } from '../src/data/map';
import { MOVES, learnedMoves } from '../src/data/moves';

const T0 = 1_700_000_000_000;

const duelOf = (party: { id: string; level: number }[], encounterId: string, seed = 7, orbs = 5, potions = 2): Duel =>
  createDuel({ tileId: 'a1', encounterId, seed, party: party.map((p) => ({ ...p, rank: 0, stage: stageForLevel(p.level) })), potions, orbs });

describe('속성 (D68: ×2 / ×½)', () => {
  it('물 > 불 > 숲 > 대지 > 바람 > 물', () => {
    expect(elementMultiplier('water', 'fire')).toBe(2);
    expect(elementMultiplier('fire', 'forest')).toBe(2);
    expect(elementMultiplier('electric', 'water')).toBe(2);
    expect(elementMultiplier('fire', 'water')).toBe(0.5);
    expect(elementMultiplier('water', 'forest')).toBe(1);
  });
});

describe('턴제 전투', () => {
  it('같은 시드·같은 선택 = 같은 결과', () => {
    const a = autoDuel(duelOf([{ id: 'igni', level: 5 }], 'ember_nest', 3));
    const b = autoDuel(duelOf([{ id: 'igni', level: 5 }], 'ember_nest', 3));
    expect(JSON.stringify(a.log)).toBe(JSON.stringify(b.log));
  });
  it('상성 좋은 기술 > 보통 > 별로, 같은 속성 기술 보너스', () => {
    const igni = activeAlly(duelOf([{ id: 'igni', level: 5 }], 'slimes_a'));
    const leaf = enemyFighter('moss_slime', 5, 0);
    const water = enemyFighter('fox_kit', 5, 0);
    const ember = MOVES.ember;
    expect(estimate(igni, leaf, ember).dmg).toBeGreaterThan(estimate(igni, water, ember).dmg * 3.5);
    expect(estimate(igni, leaf, ember).type).toBe(2);
    // 같은 위력 40: 불씨(🔥, 같은 속성)가 몸통박치기(무속성)보다 세다 (상대가 보통일 때)
    const rock = enemyFighter('thorn_boar', 5, 0);
    expect(estimate(igni, rock, ember).dmg).toBeGreaterThan(estimate(igni, rock, MOVES.tackle).dmg * (igni.def ? 1 : 1));
  });
  it('물리/마법: 물안개 여우는 마법을 막고 물리는 잘 맞는다', () => {
    const wolf = activeAlly(duelOf([{ id: 'skywarden', level: 10 }], 'mist_ford'));
    const fog = enemyFighter('fog_fox', 10, 0);
    expect(estimate(wolf, fog, MOVES.gust).resisted).toBe(true); // 마법
    expect(estimate(wolf, fog, MOVES.spark).dmg).toBeGreaterThan(estimate(wolf, fog, MOVES.gust).dmg * 2);
  });
  it('빠른 쪽이 먼저, 선공 기술은 항상 먼저', () => {
    const d = duelOf([{ id: 'igni', level: 5 }], 'slimes_a');
    const ev = doTurn(d, { kind: 'move', index: activeAlly(d).moves.findIndex((m) => m.id === 'quick') });
    const first = ev.find((e) => e.t === 'move');
    expect(first && first.t === 'move' && first.uid).toBe('a:igni');
  });
  it('교체는 한 턴을 쓰고, 쓰러지면 다음 동료를 고른다', () => {
    const d = duelOf([{ id: 'igni', level: 3 }, { id: 'tidekit', level: 3 }], 'ember_nest', 11);
    doTurn(d, { kind: 'switch', uid: 'a:tidekit' });
    expect(activeAlly(d).defId).toBe('tidekit');
    // 강제로 쓰러뜨려 보기
    activeAlly(d).hp = 1;
    for (let i = 0; i < 20 && !d.needSwitch && !d.over; i++) doTurn(d, { kind: 'move', index: 0 });
    if (d.needSwitch) {
      forceSwitch(d, 'a:igni');
      expect(activeAlly(d).defId).toBe('igni');
    }
  });
  it('보스에게서는 도망칠 수 없고, 잡을 수도 없다', () => {
    const d = duelOf([{ id: 'igni', level: 30 }], 'boss_treant');
    while (!activeEnemy(d).isBoss) activeEnemy(d).hp = 0, doTurn(d, { kind: 'move', index: 0 });
    doTurn(d, { kind: 'run' });
    expect(d.over).not.toBe('run');
    expect(doTurn(d, { kind: 'orb' }).some((e) => e.t === 'capture')).toBe(false);
  });
  it('포획: 체력이 낮고 상태이상이면 잘 잡힌다', () => {
    const e = enemyFighter('fox_kit', 4, 0);
    const full = captureChance(e);
    e.hp = Math.round(e.maxHp * 0.1);
    const low = captureChance(e);
    e.status = 'poison';
    expect(low).toBeGreaterThan(full);
    expect(captureChance(e)).toBeGreaterThan(low);
  });
  it('회복약은 체력 50%를 회복하고 한 턴을 쓴다', () => {
    const d = duelOf([{ id: 'igni', level: 5 }], 'ember_nest');
    const a = activeAlly(d);
    a.hp = 10;
    doTurn(d, { kind: 'potion' });
    expect(d.used.potion).toBe(1);
    expect(a.hp).toBeGreaterThan(10);
  });
});

describe('성장 (경험치·기술·진화)', () => {
  it('전투에서 이기면 경험치로 레벨업하고, 새 기술을 배우고, Lv.10에 진화한다', () => {
    const g = newGame(T0);
    g.spirits.igni.level = 9;
    g.spirits.igni.xp = 0;
    const r = enterTile(g, 'a1', T0);
    if (r.type !== 'duel') throw new Error();
    r.duel.xp.igni = 400; // 튜토리얼 배율 포함 Lv.10은 넘고 Lv.25는 못 넘는 양
    r.duel.over = 'win';
    const sum = finishDuel(g, r.duel, T0);
    expect(g.spirits.igni.level).toBeGreaterThanOrEqual(10);
    expect(xpToNext(9)).toBeLessThan(400);
    expect(g.spirits.igni.stage).toBe(2);
    expect(sum.evolved).toEqual([{ id: 'igni', stage: 2 }]);
    // Lv.7 → 8이 되면 화염 발톱을 배운다
    const g2 = newGame(T0);
    g2.spirits.igni.level = 7;
    const s2 = { xp: [], learned: [], evolved: [] } as Parameters<typeof giveXp>[3];
    giveXp(g2, 'igni', xpToNext(7), s2);
    expect(s2.learned).toEqual([{ id: 'igni', moves: ['flame_claw'] }]);
  });
  it('잡은 몬스터는 그 레벨의 동료가 되고, 같은 종을 또 잡으면 경험치', () => {
    const g = newGame(T0);
    const d = duelOf([{ id: 'igni', level: 5 }], 'boar_den');
    d.captured.push({ species: 'tidekit', level: 4 });
    d.over = 'win';
    finishDuel(g, d, T0);
    expect(g.spirits.tidekit.level).toBe(4);
    expect(partyIds(g)).toContain('tidekit');
    const d2 = duelOf([{ id: 'igni', level: 5 }], 'boar_den');
    d2.captured.push({ species: 'tidekit', level: 4 });
    d2.over = 'win';
    const s2 = finishDuel(g, d2, T0);
    expect(s2.captured[0].isNew).toBe(false);
    expect(g.spirits.tidekit.level).toBeGreaterThanOrEqual(5);
  });
  it('기술은 배운 것 중 4개까지 고른다', () => {
    const g = newGame(T0);
    g.spirits.igni.level = 12;
    expect(learnedMoves('igni', 12).length).toBeGreaterThan(4);
    expect(setMoves(g, 'igni', ['ember', 'quick'])).toBeNull();
    expect(setMoves(g, 'igni', ['inferno'])).not.toBeNull(); // 아직 안 배움
  });
  it('파티: 최대 인원, 선두 바꾸기', () => {
    const g = newGame(T0);
    for (const id of ['tidekit', 'rocky', 'leafpup']) addSpirit(g, id, 3);
    expect(partyIds(g)).toHaveLength(3);
    expect(toggleParty(g, 'leafpup')).toMatch('3명');
    makeLead(g, 'rocky');
    expect(partyIds(g)[0]).toBe('rocky');
  });
  it('상점과 소환', () => {
    const g = newGame(T0);
    g.gold = 1000;
    expect(buy(g, 'potion')).toBeNull();
    expect(buy(g, 'orb')).toBeNull();
    expect(g.items.potion).toBe(3);
    expect(g.summonStones).toBe(1);
    g.cleared.push('a8');
    g.summonStones = 20;
    const r = summon(g, 'fire');
    expect('duplicate' in r && r.duplicate).toBe(true); // 엠버 칙은 이미 있음 → 경험치
  });
});

describe('지도', () => {
  it('보스 칸을 지나지 않고는 그 너머로 갈 수 없다', () => {
    const seen = new Set(['start']);
    const q = ['start'];
    while (q.length) {
      const t = TILE_BY_ID[q.shift()!];
      for (const n of neighborsOf(t)) if (!seen.has(n.id) && n.id !== 'b1') (seen.add(n.id), q.push(n.id));
    }
    for (const id of ['c1', 'c2', 'b2', 'gate']) expect(seen.has(id)).toBe(false);
  });
  it('P01: 스테이지 100개, 보스 025·050·075·100', () => {
    const st = MAPS.P01.tiles.filter((t) => t.stage).map((t) => t.stage!).sort((a, b) => a - b);
    expect(st).toEqual(Array.from({ length: 100 }, (_, i) => i + 1));
    for (const n of [25, 50, 75, 100]) expect(MAPS.P01.tiles.find((x) => x.stage === n)!.kind).toBe('boss');
    expect(TILES.length).toBe(new Set(TILES.map((t) => t.id)).size);
  });
  it('P01은 튜토리얼을 끝내야 열린다', () => {
    const g = newGame(T0);
    expect(travel(g, 'P01')).toMatch('튜토리얼');
    g.cleared.push('b2');
    expect(travel(g, 'P01')).toBeNull();
    expect([...reachableTiles(g)]).toEqual(['p01-001']);
  });
  it('주인공은 클리어한 칸을 따라 걸어간다', () => {
    const g = newGame(T0);
    g.cleared.push('a1', 'a2', 'a3');
    g.lastTile = 'start';
    expect(walkPath(g, 'a4')).toEqual(['start', 'a1', 'a2', 'a3', 'a4']);
  });
  it('이긴 칸은 쿨타임(튜토리얼 1분, 본편 10분, 보스 6시간) 뒤 다시 나타난다', () => {
    expect(respawnMs(TILE_BY_ID.a1)).toBe(BALANCE.respawn.tutorialBattleMin * 60_000);
    expect(respawnMs(TILE_BY_ID['p01-001'])).toBe(BALANCE.respawn.battleMin * 60_000);
    expect(respawnMs(TILE_BY_ID['p01-025'])).toBe(BALANCE.respawn.bossMin * 60_000);
    const g = newGame(T0);
    const r = enterTile(g, 'a1', T0);
    if (r.type !== 'duel') throw new Error();
    finishDuel(g, autoDuel(r.duel), T0);
    expect(enterTile(g, 'a1', T0 + 10_000).type).toBe('error');
    expect(enterTile(g, 'a1', T0 + 61_000).type).toBe('duel');
  });
});

describe('저장', () => {
  it('직렬화 왕복, 이전 버전은 새 게임', () => {
    const g = newGame(T0);
    expect(deserialize(serialize(g))).toEqual(g);
    expect(deserialize(JSON.stringify({ ...g, version: SAVE_VERSION - 1 }))).toBeNull();
    expect(deserialize('{"version":999}')).toBeNull();
    expect(deserialize('not json')).toBeNull();
  });
});
